package rc

import (
	"consensus/common/pkg/geography"
	"consensus/internal/env"
	"consensus/internal/experiment"
	"consensus/internal/variate"
	"github.com/jinzhu/gorm"
)

/*
与raft对比
1、每个消息只需要裁判节点及对应的提供者节点、使用者节点确认即可；
2、裁判节点相当于leader节点；

共识流程：
1、客户端节点创建请求交易，并发送给服务使用者节点跟服务提供者节点；
  （基于服务节点的编号发送，编号0为裁判节点，i与sum-i为对应的服务参与者节点，因为服务节点总数量必须设置为大约2的单数）
2、服务使用者节点跟服务提供者节点，将待确认消息发送给裁判节点；
3、裁判节点对比待确认交易数据，并生成确认消息，进行全网广播；
4、服务参与者节点收到确认消息之后，存储到本地区块链
*/

// 客户端多组节点并发实验
func Exp1(db *gorm.DB, clientType, serverType string) {
	// 客户端节点数量从 initnumb 增加到 limitnumb，每次增加10个
	initnumb := int64(100)
	limitnumb := int64(200)
	serverNumb := int64(20)
	exp1And5Var := variate.NewIntVariate(env.ClientNO, initnumb, limitnumb, 100)
	// reinumb为微电网个数(本共识算法用不到)
	exp1AndEnv := env.New(initnumb, serverNumb, 2, 0, 0.1, geography.Local, 1)
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("Exp1", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}

// 服务端节点增多实验
func Exp2(db *gorm.DB, clientType, serverType string) {
	// 客户端节点数量从 initnumb 增加到 limitnumb，每次增加10个
	initnumb := int64(10)
	limitnumb := int64(10)
	clientnumb := int64(1)
	exp1And5Var := variate.NewIntVariate(env.ServerNO, initnumb, limitnumb, 10)
	// reinumb为微电网个数(raft算法用不到)
	exp1AndEnv := env.New(clientnumb, initnumb, 2, 0, 0.1, geography.Local, 1)
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("Exp1", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}
