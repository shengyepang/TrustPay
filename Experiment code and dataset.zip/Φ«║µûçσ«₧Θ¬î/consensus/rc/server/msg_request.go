package server

import (
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
	TypeMessage "consensus/rc/message"
	cmap "github.com/orcaman/concurrent-map"
)

// 服务参与者节点处理来自客户端的request消息
func (svr *Server) HandleRequest(msg message.Message) {
	//height := svr.GetBlockChanHeight()
	//data.Message.Block.Header.Height = height

	data := msg.Payload.(*TypeMessage.Message_State)
	// 将共识状态设置为准备阶段
	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_Prepare_Nomal)
	// 记录首次消息时间
	svr.SaveCheckAbortMaxDeadLineTime(msg.RequestID)
	data.Message.Block.NodeID = svr.ID
	//data.Message.Block.Header.Height = height

	t := util.Timestamp()
	msgs := &message.Message{ //消息的类型
		Type:      TypeMessage.Uncommitted.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: []string{svr.GetRefereeNodeId()},
		RequestID: msg.RequestID,
		Payload:   msg.Payload,
	}
	//fmt.Println("serverID:", svr.ID)

	// 监听 UncommitConsensusFail 事件,在规定时间内服务参与者节点未收到裁判节点的验证通过广播
	svr.ListenTimeOut(&msg, &svr.UnCommitMsgs, svr.UncommitConsensusFail)
	svr.Send(*msgs)
}

// 服务参与者节点在规定时间内未收到裁判节点的广播消息(即裁判节点核对使用者跟提供者的消息失败)
func (svr *Server) UncommitConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 当前 msg.RequestID 是否已经完成 Uncommitted 阶段
	if d, y := svr.ConsensusStatus.Get(msg.RequestID); y {
		if d.(TypeMessage.MsgState) == TypeMessage.Msg_Uncommitted_Success {
			return
		}
	}

	// 当服务参与者提交的消息未共识成功时，重新发起消息
	svr.HandleRequest(*msg)
}

// 获取区块高度，此处是区块数量，即区块高度+1
func (svr *Server) GetBlockChanHeight() int64 {
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return int64(len(svr.BlockChan)) + 1
}

// 保存请求的首次消息时间
func (svr *Server) SaveCheckAbortMaxDeadLineTime(RequestID string) {
	t := util.Timestamp()
	if !svr.CheckAbortMaxDeadLineTime.Has(RequestID) {
		// 记录消息起始日期
		svr.CheckAbortMaxDeadLineTime.Set(RequestID, t)
	}
}
