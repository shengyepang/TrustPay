package server

import (
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
	TypeMessage "consensus/rc/message"
)

// 裁判节点收到服务参与者节点发送的交易请求，核对交易并广播
func (svr *Server) HandleUncommit(msg message.Message) {
	data := msg.Payload.(*TypeMessage.Message_State)

	// 若是第一次收到改请求交易，则存储；否则，对比请求交易数据并广播
	result, oldmsg := svr.IsFirstMessage(msg.RequestID, data, &svr.UnCommitMsgs)
	if !result { // 对比服务参与者请求消息的具体数据，之后广播区块数据
		olddata := oldmsg.([]*TypeMessage.Message_State)[0]
		//fmt.Println("new:", data.Message.Block)
		//fmt.Println("old:", olddata.Message.Block)
		//fmt.Println("serverID0:", svr.ID)

		if compareMsg(data, olddata, msg.ClientID) {
			// 添加区块高度
			height := svr.GetBlockChanHeight()
			data.Message.Block.Header.Height = height
			svr.UncommitConsensusSuccess(&msg)
		}
	}
}

// 对比请求交易数据的一致性
func compareMsg(msg1, msg2 *TypeMessage.Message_State, clintId string) bool {
	if msg1.SendID != msg2.SendID {
		return false
	}
	if msg1.HashMessage != msg2.HashMessage {
		return false
	}
	if msg1.Message.Block.Header.ID != msg2.Message.Block.Header.ID {
		return false
	}
	if msg1.Message.Block.Header.Timestamp != msg2.Message.Block.Header.Timestamp {
		return false
	}

	if msg1.Message.Block.Body.Data[clintId].(string) != msg2.Message.Block.Body.Data[clintId].(string) {
		return false
	}
	return true
}

// 收到服务参与者的请求消息，且数据一致，则广播commit消息
func (svr *Server) UncommitConsensusSuccess(msg *message.Message) {

	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_Uncommitted_Success)

	data := msg.Payload.(*TypeMessage.Message_State)
	t := util.Timestamp()
	newmsg := &message.Message{ //消息的类型
		Type:      TypeMessage.Commit.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: svr.BroadCastToAllNode(), // 定义消息接受节点
		RequestID: msg.RequestID,
		Payload:   data,
	}
	svr.Send(*newmsg) //网络延迟
}
