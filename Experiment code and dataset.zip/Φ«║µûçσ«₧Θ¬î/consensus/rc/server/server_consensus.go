package server

import (
	"consensus/common/pkg/message"
	TypeMessage "consensus/rc/message"
)

// 接收并解析消息
func (svr *Server) HandleMessage(msg message.Message) {
	switch msg.Type {
	// 服务参与者(使用者、提供者)节点处理客户端节点的request消息
	case TypeMessage.Request.String():
		svr.HandleRequest(msg)
	// 裁判节点收集服务参与者节点广播的验证消息
	case TypeMessage.Uncommitted.String():
		svr.SaveUncommitHandleChannel <- msg
	// 所有节点处理确认消息，并更新存储新区块
	case TypeMessage.Commit.String():
		svr.SaveCommitHandleChannel <- msg
	}

}
