package client

import (
	"consensus/common/pkg/blocker"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/node"
	"consensus/common/pkg/request"
	"consensus/common/pkg/util"
	"consensus/rc/block"
	TypeMessage "consensus/rc/message"
	"consensus/rc/model"
	"consensus/rc/server"
	"consensus/rc/tool"
	"consensus/rc/vdf_go"
	"context"
	"fmt"
	"math/rand"
	"strconv"
	"sync/atomic"
	"time"
)

var (
	// Request超时时间
	DeadLine = 100 * 1000 * time.Millisecond
)

// 客户端节点,即发起交易的客户端
type Client struct {
	*node.ClientBase                        // 节点基础信息，在公共部分定义
	*blocker.Blocker                        // 禁用名单
	ReportCh         chan<- *request.Event  // experiment report channel 实验报道通道
	Servers          []interface{}          // 服务节点列表
	Clients          []interface{}          // 客户端节点列表
	Committees       []interface{}          // 共识节点列表
	TestParams       map[string]interface{} // 测试平台传递的测试参数
	RequestEvent     request.Event          // 请求事件，可能是客户端发起的消息
	FishCount        uint32
	Ctx              context.Context      //用于在程序单元Goroutine之间传递运行状态
	DeadChannel      chan message.Message //消息通道
	Nodei            interface{}          // 服务端首节点(raft中的leader节点)
}

// TODO 公共接口
// 将消息发送给测试平台
func (c *Client) HandleMessage(msgs message.Message) {
	tool.SafeSend(c.DeadChannel, msgs)
}

func (c *Client) ListenHandlMessage(RequestID string) {
	go func() {
		for {
			select {
			case <-c.Ctx.Done():
				t := util.Timestamp()
				c.ReportCh <- &request.Event{
					Status:    request.Speculate,
					ID:        RequestID,
					Timestamp: t,
					ClientID:  c.ID,
				}
				c.ReportCh <- &request.Event{
					Status:    request.Aborted,
					ID:        RequestID,
					Timestamp: t,
					ClientID:  c.ID,
				}
				close(c.DeadChannel)
				return
			case msg := <-c.DeadChannel:
				// 处理消息通道中的消息
				switch msg.Type {
				case TypeMessage.Commit.String(): // 共识成功
					FishCount := atomic.AddUint32(&c.FishCount, 1)
					if int(FishCount) == len(c.Servers)-1 {
						c.ReportCh <- &request.Event{
							Status:    request.Speculate,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						c.ReportCh <- &request.Event{
							Status:    request.Committed,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						return
					}
				case TypeMessage.Aborted.String(): // 终止
					FishCount := atomic.AddUint32(&c.FishCount, 1)
					if int(FishCount) == len(c.Servers)-1 {
						c.ReportCh <- &request.Event{
							Status:    request.Speculate,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						c.ReportCh <- &request.Event{
							Status:    request.Aborted,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						return
					}
				}
			}
		}
	}()
}

func (c *Client) GetNode() *node.Node {
	return c.Node
}

// 初始化客户端
func (c *Client) Init(id string, tolerance uint, servers []interface{}, reportCh chan<- *request.Event) {
	c.ClientBase = node.NewClientBase(id, node.Client)
	c.Blocker = blocker.New(tolerance)
	c.Servers = servers
	c.ReportCh = reportCh
	c.DeadChannel = make(chan message.Message, len(c.Servers))
	c.Nodei = c.GetFisrtServer() //获取服务端的首节点
}

// 获取主节点
func (c *Client) GetFisrtServer() interface{} {
	// 暂定第一个服务节点为raft的主节点
	return c.Servers[0]
}

// create a request message with the op and send it to the best server
func (c *Client) Request(op interface{}, id string) {
	seed, vdf := c.GetVDF()
	block := op.(*block.Block)
	// 将区块封装在请求消息中
	RequestMessage := &model.RequestMessage{
		VDFSeed:    seed,
		VDF:        vdf,
		Committees: c.Committees,
		Block:      block,
		Nodei:      c.Nodei,
	}

	msge := &TypeMessage.Message_State{
		Message: RequestMessage,
		//SendID:  c.Nodei.(node.ImpServer).GetID(), // 消息节点ID，此处为raft的leader节点
	}
	// 获取目标节点ID(对应的服务参与者和服务提供者)
	targetIDs := make([]string, 0)
	for {
		i := rand.Intn(len(c.Servers))
		if i == 0 {
			continue
		}
		other := len(c.Servers) - i
		targetIDs = append(targetIDs, "server_"+strconv.Itoa(i), "server_"+strconv.Itoa(other))
		break
	}

	t := util.Timestamp()
	msg := &message.Message{ //消息的类型
		Type:      TypeMessage.Request.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  c.ID, //发送者ID
		ClientID:  c.ID,
		TargetIDS: targetIDs,
		RequestID: id,
		Payload:   msge,
	}
	// report request created
	c.ReportCh <- &request.Event{
		Status:    request.Created,
		ID:        msg.RequestID,
		Timestamp: t,
		ClientID:  c.ID,
	}
	// send request
	c.Ctx, _ = context.WithTimeout(context.Background(), DeadLine)
	c.ListenHandlMessage(msg.RequestID)
	c.Send(*msg) //网络延迟
}

//延迟函数
func (c *Client) GetVDF() ([32]byte, [516]byte) {
	if data, y := c.TestParams["Vdf"]; y {
		if data.(string) == "1" {

			input := [32]byte{}
			rand.Read(input[:])

			vdf := vdf_go.New(20, input)
			//返回延迟函数的输出通道
			outputChannel := vdf.GetOutputChannel()

			start := time.Now()
			//
			vdf.Execute()

			duration := time.Now().Sub(start)

			log.Info(fmt.Sprintf("VDF computation finished, time spent %s", duration.String()))

			output := <-outputChannel
			return input, output

		}
	}
	return [32]byte{}, [516]byte{}
}

//破坏客户端对应的节点并停止相关的线程
func (c *Client) Destroy() {
	c.Node.Destroy()
}

// 基于实验传入的参数，在客户端中设置相应的实验参数
func (c *Client) SetTestParams(param map[string]interface{}) {
	c.TestParams = param
	deadLine, _ := strconv.ParseFloat(param["DeadLine"].(string), 10)
	DeadLine = time.Duration(deadLine*1000) * time.Millisecond
}

// 获取请求操作
func (c *Client) GetRequestOP() interface{} {
	//通过添加UUID使的id是唯一的
	id := c.GetNode().ID + " " + tool.UUID()
	block1 := &block.Block{
		Header: block.BlockHeader{
			Timestamp: tool.Timestamp(),
			ID:        tool.UUID(),
			PreHash:   "",
		},
		Body: block.BlockBody{
			Data: map[string]interface{}{c.GetNode().ID: id},
		},
	}

	if _, y := c.TestParams["isConflict"]; y {
		block1 = &block.Block{
			Header: block.BlockHeader{
				Timestamp: tool.Timestamp(),
				ID:        tool.UUID(),
				PreHash:   "",
			},
			Body: block.BlockBody{
				Data: map[string]interface{}{"A": id},
			},
		}
	}
	return block1
}

// 设定客户端节点中的共识节点集合
func (c *Client) GetJoinConsensusNodes() []interface{} {
	committes := make([]interface{}, 0)
	// 遍历服务端节点，依此添加到客户端节点的共识节点列表中
	// 下标0为leader节点
	for j := 1; j < len(c.Servers); j++ {
		svr := *(c.Servers[j].(*server.Server))
		c.Committees = append(c.Committees, svr)
		committes = append(committes, svr)
	}

	return committes
}
