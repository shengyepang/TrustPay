package message

import (
	"consensus/rc/model"
)

type Type uint8

// 消息状态
const (
	Request Type = iota
	Uncommitted
	Commit
	// 裁判共识只包含上述三个阶段
	Prepare
	PrePrepare
	Aborted
	PrePrepareAborted
	Finished
	Credit
)

func (mt Type) String() string {
	switch mt {
	case Request:
		return "Request"
	case PrePrepare:
		return "PrePrepare"
	case Uncommitted:
		return "Uncommitted"
	case Commit:
		return "Commit"
	case Aborted:
		return "Aborted"
	case Finished:
		return "Finished"
	case Credit:
		return "Credit"
	case PrePrepareAborted:
		return "PrePrepareAborted"
	default:
		return "Unknown"
	}
}

type MsgState byte

// 共识状态
const (
	Msg_Prepare_Success MsgState = iota
	Msg_Prepare_Fail
	Msg_Prepare_Nomal
	Msg_Uncommitted_Success
)

type Message_State struct {
	SendID      string                // 消息发送节点
	Message     *model.RequestMessage // 消息体
	HashMessage string                // 请求消息的hash
	Deadline    int64
}
