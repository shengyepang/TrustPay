package rc

import (
	"fmt"
	"math/rand"
	"testing"
)

func Test_demo_test(t *testing.T) {
	for i := 0; i < 10; i++ {
		i1 := rand.Intn(2)
		fmt.Println(i1)
	}
}
