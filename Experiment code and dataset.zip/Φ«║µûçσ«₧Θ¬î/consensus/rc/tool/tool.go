package tool

import (
	"consensus/common/pkg/message"
	"consensus/rc/vdf_go"
	"crypto/sha256"
	"encoding/hex"
	jsoniter "github.com/json-iterator/go"
	uuid "github.com/satori/go.uuid"
	"log"
	"time"
)

//发送消息到通道
func SafeSend(ch chan message.Message, value message.Message) (closed bool) {
	defer func() {
		// recover() 在defer函数中,用来终止一个go并发程序中的panicking过程，使代码恢复正常运行
		if recover() != nil {
			closed = true
		}
	}()
	ch <- value
	return false
}

//随机生成UUID，即通用唯一识别码
func UUID() string {
	u1 := uuid.NewV4().String()
	return u1
}

func Timestamp() int64 {
	return TimestampOf(time.Now())
}

// Timestamp get a timestamp of specified time, microseconds
func TimestampOf(t time.Time) int64 {
	return t.UnixNano() / 1e3
}

// 计算obj的hash值
func Digest(obj interface{}) (string, error) {
	var json = jsoniter.ConfigCompatibleWithStandardLibrary
	content, err := json.Marshal(obj)
	if err != nil {
		log.Printf("[Crypto] marshl the object error: %s", err)
		return "", err
	}
	return Hash(content), nil
}

//哈希值
func Hash(content []byte) string {
	h := sha256.New()
	h.Write(content)
	return hex.EncodeToString(h.Sum(nil))
}

// VDF验证
func VDF_Verify(Seed [32]byte, VDF [516]byte) bool {
	return true
	vdf := vdf_go.New(1, Seed)
	return vdf.Verify(VDF)
}
