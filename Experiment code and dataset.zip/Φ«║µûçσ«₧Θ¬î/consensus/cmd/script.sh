#!/bin/bash


for i in {1..5}
do
    echo "Running command: $i"
    go run main.go -t raft -f exp1
done


for i in {1..5}
do
    echo "Running command: $i"
    go run main.go -t rc -f exp1
done