package main

import (
	"consensus/REIBFT"
	"consensus/common/pkg/log"
	"consensus/common/pkg/network"
	"consensus/internal/tool"
	"consensus/raft"
	"consensus/rc"
	"fmt"
	"github.com/jinzhu/gorm"
	"github.com/urfave/cli/v2"

	reibft_c "consensus/REIBFT/Client"
	reibft_s "consensus/REIBFT/Server"
	raft_c "consensus/raft/client"
	raft_s "consensus/raft/server"
	rc_c "consensus/rc/client"
	rc_s "consensus/rc/server"
	"net/http"
	_ "net/http/pprof"
	"os"
	"runtime"
	"strings"
	"time"
)

func main() {

	runtime.SetMutexProfileFraction(1) // 开启对锁调用的跟踪
	runtime.SetBlockProfileRate(1)     // 开启对阻塞操作的跟踪
	go func() {
		// 启动一个 http server，注意 pprof 相关的 handler 已经自动注册过了
		if err := http.ListenAndServe(":6070", nil); err != nil {
			log.Fatal(err)
		}
	}()
	log.ErrorLogger.Info("Hello, ds!")

	app := &cli.App{ //创建一个应用程序
		// 设置对应的参数
		Flags: []cli.Flag{
			&cli.StringFlag{
				Name:    "topic",
				Value:   "",
				Aliases: []string{"t"},
				Usage:   "当前共识算法的类型 raft rc reibft",
			},
			&cli.StringFlag{
				Name:    "func",
				Value:   "",
				Aliases: []string{"f"},
				Usage:   "func",
			},
			&cli.StringFlag{
				Name:    "start",
				Value:   "",
				Aliases: []string{"s"},
				Usage:   "网络时间,区间开始",
			},
			&cli.StringFlag{
				Name:    "end",
				Value:   "",
				Aliases: []string{"e"},
				Usage:   "网络时间,区间结束",
			},
		},
		// 程序执行函数
		Action: func(c *cli.Context) error {
			//拿到第一个参数，获取参数
			if c.NArg() > 0 { //参数数量
			}
			topic := c.String("topic")
			if len(topic) == 0 {
				fmt.Println("请输入topic参数")
				return nil
			}
			f := c.String("func")
			s := c.Float64("start")
			e := c.Float64("end")
			network.NetTimeStart = s
			network.NetTimeEnd = e

			fmt.Println("输入参数:", topic, f, s, e)
			// 共识测试函数
			StartNet(topic, f)

			return nil
		},
	}
	// cli程序运行
	err := app.Run(os.Args)
	if err != nil {

	}
}

func StartNet(cmd string, f string) {
	// 注册测试数据存储数据库
	dbName := fmt.Sprintf("result_%s%v.db", cmd, time.Now().Format("2006_01_02-15_04_05"))
	db := initDB(dbName, false)
	// 基于传参的不同，测试不同的共识算法以及不同的测试函数
	switch cmd { //传的参数不同选择不同
	case "reibft":
		clientType := tool.RegisterType(reibft_c.Client{})
		serverType := tool.RegisterType(reibft_s.Server{})
		switch strings.ToLower(f) {
		case "exp1":
			REIBFT.Exp1(db, clientType, serverType)
			break
		case "exp2":
			REIBFT.Exp2(db, clientType, serverType)
			break
		case "exp3":
			REIBFT.Exp3(db, clientType, serverType)
			break
		case "exp4":
			REIBFT.Exp4(db, clientType, serverType)
			break
		}
		break
	case "raft":
		clientType := tool.RegisterType(raft_c.Client{})
		serverType := tool.RegisterType(raft_s.Server{})
		switch strings.ToLower(f) {
		case "exp1":
			raft.Exp1(db, clientType, serverType)
			break
		case "exp2":
			raft.Exp2(db, clientType, serverType)
			break
		}
		break
	case "rc":
		// serverType为consensus/rc/server.Server
		// clientType为consensus/rc/client.Client
		clientType := tool.RegisterType(rc_c.Client{})
		serverType := tool.RegisterType(rc_s.Server{})
		switch strings.ToLower(f) {
		case "exp1":
			rc.Exp1(db, clientType, serverType)
			break
		case "exp2":
			rc.Exp2(db, clientType, serverType)
			break
		}
		break
	}
}

// 初始化数据库
func initDB(name string, reset bool) *gorm.DB {
	sugar := log.New()

	if reset {
		_ = os.Remove(name)
	}

	if db, err := gorm.Open("sqlite3", name+"?cache=shared"); err != nil {
		sugar.Panic("SQLite database open fail", err)
		_ = sugar.Sync()
		return nil
	} else {
		return db
	}
}
