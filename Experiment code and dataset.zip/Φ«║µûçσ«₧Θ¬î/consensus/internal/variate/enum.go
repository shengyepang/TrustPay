package variate

import (
	"consensus/common/pkg/log"
	"consensus/internal/env"
	"consensus/internal/execution"
	"fmt"
	"reflect"
)

// boolean type variate
type EnumVariate struct {
	name   env.VariateName // variate name
	values []string        // possible values of the enumerate
	index  int             // current index of the values slice
}

// New EnumVariate Create a boolean type variate
func NewEnumVariate(name env.VariateName, values ...string) *EnumVariate {
	bv := &EnumVariate{
		name:   name,
		values: values,
		index:  0,
	}

	bv.validate()

	return bv
}

func (ev *EnumVariate) value() interface{} {
	return ev.values[ev.index]
}

// validate checks whether variate is valid
func (ev *EnumVariate) validate() {
	sugar := log.New()
	defer sugar.Sync()

	if ev.name == "" {
		sugar.Panicf("variate should have a name")
	}

	emptyEnv := env.Env{}
	v := reflect.ValueOf(&emptyEnv).Elem().FieldByName(string(ev.name))

	if !v.IsValid() {
		sugar.Panicf("not valid variate name: %v", ev.name)
	}

	if v.Type() != reflect.TypeOf(ev.value()) {
		sugar.Panicf("type mismatch for variate %v: set %v to %v", ev.name, reflect.TypeOf(ev.value()), v.Type())
	}
}

// next flip the value of a boolean variate
func (ev *EnumVariate) next() (done bool) {
	if ev.index >= len(ev.values)-1 {
		return true
	}

	ev.index++

	return ev.index == len(ev.values)
}

// BlendIn merge the variate's current value into the target execution
// and automatically trigger value stepping
func (ev *EnumVariate) BlendIn(exe *execution.Execution) bool {
	newVal := reflect.ValueOf(ev.value())
	reflect.ValueOf(exe).Elem().FieldByName(string(ev.name)).Set(newVal)
	return ev.next()
}

// Value return the current state of variate in string
func (ev *EnumVariate) String() string {
	return fmt.Sprintf("%v_%v", ev.name, ev.value())
}

func (ev *EnumVariate) Name() string {
	return fmt.Sprintf("%v", ev.name)
}
