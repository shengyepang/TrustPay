package variate

import (
	"consensus/common/pkg/log"
	"consensus/internal/env"
	"consensus/internal/execution"
	"fmt"
	"reflect"
)

// int type variate
type IntVariate struct {
	name  env.VariateName // variate name
	value int64           // variate's current value
	limit int64           // reachable bound, inclusive
	step  int64           // variate's step, positive for increasing, negative for decreasing
}

// New create a new int variate
func NewIntVariate(name env.VariateName, initValue, limit, step int64) *IntVariate {
	iv := &IntVariate{
		name:  name,
		value: initValue,
		limit: limit,
		step:  step,
	}

	// 检查变量配置是否合理
	iv.validate()

	return iv
}

// validate checks whether variate is valid
func (iv *IntVariate) validate() {
	sugar := log.New()
	defer sugar.Sync()

	// name
	emptyEnv := env.Env{}
	fieldValue := reflect.ValueOf(&emptyEnv).Elem().FieldByName(string(iv.name))
	if !fieldValue.IsValid() {
		sugar.Panicf("variate %v not recongnized", iv.name)
	}

	if fieldValue.Type() != reflect.TypeOf(iv.value) {
		sugar.Panicf("type mismatch for variate %v: set int to %v", iv.name, fieldValue.Type())
	}

	// step 每次增加的数量不能为0
	//if iv.step == 0 {
	//	sugar.Panicf("variate %v has a 0 step", iv.name)
	//}

	// limit & value
	var decreasing = iv.step < 0
	if decreasing {
		if iv.limit > iv.value {
			sugar.Panicf("decreasing variate %v has a init value less than limit", iv.name)
		}
	} else {
		if iv.limit < iv.value {
			sugar.Panicf("increasing variate %v has a init value greater than limit", iv.name)
		}
	}
}

// next increase/decrease value by variate step.
func (iv *IntVariate) next() (done bool) {
	// whether the variate are decreasing
	var decreasing = iv.step < 0

	// compare first
	if decreasing {
		done = iv.value < iv.limit
	} else {
		done = iv.value > iv.limit
	}

	// make the step after comparing
	iv.value += iv.step

	return done
}

// BlendIn merge the variate's current value into the target execution
// and automatically trigger value stepping
func (iv *IntVariate) BlendIn(exe *execution.Execution) bool {
	reflect.ValueOf(exe).Elem().FieldByName(string(iv.name)).SetInt(iv.value)
	return iv.next()
}

// Value return the current state of variate in string
func (iv *IntVariate) String() string {
	return fmt.Sprintf("%v_%v", iv.name, iv.value)
}

func (iv *IntVariate) Name() string {
	return fmt.Sprintf("%v", iv.name)
}
