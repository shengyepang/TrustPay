package variate

import (
	"consensus/internal/execution"
)

// variate is the empty interface for control variate
type Variate interface {

	// next increase/decrease value by variate step.
	next() (done bool)

	// validate checks whether variate is valid
	validate()

	// BlendIn merge the variate's current value into the target execution
	// and automatically trigger value stepping
	BlendIn(exe *execution.Execution) (done bool)

	// Value return the current state of variate in string
	String() string

	// Name
	Name() string
}
