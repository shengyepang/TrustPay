package variate

import (
	"consensus/common/pkg/log"
	"consensus/internal/env"
	"consensus/internal/execution"
	"fmt"
	d "github.com/shopspring/decimal"
	"reflect"
)

// DecimalVariate float type variate
type DecimalVariate struct {
	name  env.VariateName // variate name
	value d.Decimal       // variate's current value
	limit d.Decimal       // reachable bound, inclusive
	step  d.Decimal       // variate's step, positive for increasing, negative for decreasing
}

// New create a new decimal variate
func NewDecimalVariate(name env.VariateName, value, limit, step float64) *DecimalVariate {
	dv := &DecimalVariate{
		name:  name,
		value: d.NewFromFloat(value),
		limit: d.NewFromFloat(limit),
		step:  d.NewFromFloat(step),
	}

	dv.validate()

	return dv
}

// validate checks whether variate is valid
func (dv *DecimalVariate) validate() {
	sugar := log.New()
	defer sugar.Sync()

	// name
	emptyEnv := env.Env{}
	fieldValue := reflect.ValueOf(&emptyEnv).Elem().FieldByName(string(dv.name))
	if !fieldValue.IsValid() {
		sugar.Panicf("variate %v not recongnized", dv.name)
	}

	if fieldValue.Type() != reflect.TypeOf(dv.value) {
		sugar.Panicf("type mismatch for variate %v: set decimal to %v", dv.name, fieldValue.Type())
	}

	// step
	if dv.step == d.Zero {
		sugar.Panicf("variate %v has a 0 step", dv.name)
	}

	// limit & value
	var decreasing = dv.step.LessThan(d.Zero)
	if decreasing {
		if dv.limit.GreaterThan(dv.value) {
			sugar.Panicf("decreasing variate %v has a init value less than limit", dv.name)
		}
	} else {
		if dv.limit.LessThan(dv.value) {
			sugar.Panicf("increasing variate %v has a init value greater than limit", dv.name)
		}
	}
}

// next increase/decrease value by variate step.
func (dv *DecimalVariate) next() (done bool) {
	// whether the variate are decreasing
	var decreasing = dv.step.LessThan(d.Zero)

	// compare first
	if decreasing {
		done = dv.value.LessThan(dv.limit)
	} else {
		done = dv.value.GreaterThan(dv.limit)
	}

	// make the step after comparing
	dv.value = dv.value.Add(dv.step)

	return done
}

// BlendIn merge the variate's current value into the target execution
// and automatically trigger value stepping
func (dv *DecimalVariate) BlendIn(exe *execution.Execution) bool {
	reflect.ValueOf(exe).Elem().FieldByName(string(dv.name)).Set(reflect.ValueOf(dv.value))
	result := dv.next()
	return result
}

// Value return the current state of variate in string
func (iv *DecimalVariate) String() string {
	return fmt.Sprintf("%v_%v", iv.name, iv.value)
}

func (iv *DecimalVariate) Name() string {
	return fmt.Sprintf("%v", iv.name)
}
