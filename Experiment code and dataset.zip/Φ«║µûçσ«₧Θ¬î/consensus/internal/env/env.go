package env

import d "github.com/shopspring/decimal"

type VariateName string

// 实验变量类型
const (
	ClientNO    = "ClientNO"
	ServerNO    = "ServerNO"
	Lambda      = "Lambda"
	ClientBFR   = "ClientBFR"
	ServerBFR   = "ServerBFR"
	GeoType     = "GeoType"
	CommitteeNo = "CommitteeNo"
)

// Env is the base config for execution generation
// d.Decimal避免小数精度丢失的第三方包
type Env struct {
	ClientNO    int64     // number of clients
	ServerNO    int64     // number of servers
	Lambda      d.Decimal // intensity of poisson process for client request generation
	ClientBFR   d.Decimal // client Byzantine fault rate, 0 - 1 (客户端拜占庭错误率，0代表不存在拜占庭节点)
	ServerBFR   d.Decimal // server Byzantine fault rate, 0 - 1 (服务端拜占庭错误率，0代表不存在拜占庭节点)
	GeoType     string    // simulation geographic locations for each node（模拟每个节点的地理位置）
	CommitteeNo int64     // 委员数量
	//REInumb     int       // 微电网数量
}

func New(clientNO, serverNO int64, lambda float64, clientBFR, serverBFR float64, geoType string, reinumb int) *Env {
	return &Env{
		ClientNO:  clientNO,
		ServerNO:  serverNO,
		Lambda:    d.NewFromFloat(lambda),
		ClientBFR: d.NewFromFloat(clientBFR),
		ServerBFR: d.NewFromFloat(serverBFR),
		GeoType:   geoType,
		//REInumb:   reinumb,
	}
}
