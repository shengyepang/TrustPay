package execution

import (
	"consensus/common/pkg/network"
	"consensus/common/pkg/node"
	"consensus/common/pkg/request"
	"consensus/internal/env"
	"consensus/internal/tool"
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
	uuid "github.com/satori/go.uuid"
	"math/rand"
	"sync"
	"time"
)

const blockTolerance = 5

// Execution contains all the config for a single test case
type Execution struct {
	env.Env
	name         string              // execution name
	requestCount int                 // test request number
	reportCh     chan *request.Event // report channel for data collection
	ctx          context.Context     // context for cancellation
	cancel       context.CancelFunc  // cancel function of context
	wg           sync.WaitGroup      // wait group for goroutine cancellation
	ParamsMap    map[string]interface{}
}

// Reproduce an execution with all values from env
func New(e *env.Env, name string) *Execution {
	ctx, cancel := context.WithCancel(context.Background())
	return &Execution{
		Env: env.Env{
			ClientNO:    e.ClientNO,
			ServerNO:    e.ServerNO,
			Lambda:      e.Lambda,
			ClientBFR:   e.ClientBFR,
			ServerBFR:   e.ServerBFR,
			GeoType:     e.GeoType,
			CommitteeNo: e.CommitteeNo,
		},
		name:         name,
		requestCount: 1000,
		reportCh:     make(chan *request.Event, 500),
		ctx:          ctx,
		cancel:       cancel,
		ParamsMap:    make(map[string]interface{}),
	}
}

func (exe *Execution) String() string {
	return fmt.Sprintf("client: %v, server: %v, geo type: %v, ", exe.ClientNO, exe.ServerNO, exe.GeoType) +
		fmt.Sprintf(
			"client byzantine fault ratio: %v, client request poisson lambda: %v, server byzantine fault ratio: %v",
			exe.ClientBFR, exe.Lambda, exe.ServerBFR,
		)
}

// create algorithm related nodes and the network
func (exe *Execution) Spawn(ClientType, ServerType string, TestParams map[string]interface{}) (clients []interface{}, servers []interface{}, net *network.Network) {
	var nodes []interface{}
	// 2. create servers
	for i := 0; i < int(exe.ServerNO); i++ {
		in := make(map[string]interface{})
		sr := tool.CreateInstance(ServerType, in)
		sr.(node.ImpServer).Init(fmt.Sprintf("server_%v", i), int(exe.ServerNO), exe.reportCh)
		// 设置测试参数
		if TestParams != nil {
			sr.(node.ImpServer).SetTestParams(TestParams)
		}
		servers = append(servers, sr)
		nodes = append(nodes, sr)
	}

	// 3. create clients
	for i := 0; i < int(exe.ClientNO); i++ {
		in := make(map[string]interface{})
		cl := tool.CreateInstance(ClientType, in)
		// servers 服务节点列表添加到客户端节点的变量中
		cl.(node.ImpClient).Init(fmt.Sprintf("client_%v", i), blockTolerance, servers, exe.reportCh)
		if TestParams != nil {
			cl.(node.ImpClient).SetTestParams(TestParams)
		}
		clients = append(clients, cl)
		nodes = append(nodes, cl)
	}

	// 为客户端节点共识节点列表
	for _, client := range clients {
		// 赋值共识组节点
		client.(node.ImpClient).GetJoinConsensusNodes()
	}

	// 使用默认
	//servers_bft := exe.ServerBFR.Mul(d.NewFromInt(exe.ServerNO)).IntPart()
	//// 控制拜占庭节点
	//for i, server := range servers {
	//	if i <= int(servers_bft)-1 {
	//		n := server.(node.ImpServer).GetNode()
	//		n.Byzantine = true
	//	} else {
	//		break
	//	}
	//}

	// 为服务端节点添加客户端节点列表和服务端节点列表
	for _, server := range servers {
		server.(node.ImpServer).SetNodes(servers, clients)
	}
	// 6. create network
	net = network.New(nodes, exe.GeoType)
	return
}

// manipulating clients and collecting result
func (exe *Execution) Start(clients, servers []interface{}, db *gorm.DB) {
	// each client has a control channel
	exe.requestCount = len(clients)
	// simulating requests independently
	for _, c := range clients {
		go exe.makeRequest(c.(node.ImpClient), exe.ParamsMap)
	}

	// collect test data
	exe.Collect(db, servers)

	// stop goroutines, complete the execution
	exe.cancel()

	exe.wg.Wait()

}

func (exe *Execution) GetRandom(end, count int) map[int]bool {
	data := make(map[int]bool)
	rand.Seed(time.Now().UnixNano())
	for i := 0; i < count; i++ {
		n := rand.Intn(end) // 生成一组[0,9]范围内的整数作为随机数
		data[n] = true
	}
	return data
}

// control the client to send a request
func (exe *Execution) makeRequest(c node.ImpClient, params map[string]interface{}) {
	var timer *time.Timer
	// 计算每个请求到下一个请求的时间
	nextTime := exe.durationTilNextRequest()
	timer = time.AfterFunc(nextTime, func() {
		exe.wg.Add(1)
		defer exe.wg.Done()
		select {
		case <-exe.ctx.Done():
			if timer != nil {
				timer.Stop()
			}
			return
		default:
			// 基于客户端节点ID构建request请求id
			id := c.GetNode().ID + " " + uuid.NewV4().String()
			// create request operation
			// 即创建一个区块
			op := c.GetRequestOP()
			// make client send it
			c.Request(op, id)
		}
	})
}

// durationTilNextRequest calculate the duration till next request
// each call get a value based on exponential distribution, thus all the requests are poisson distributed
// https://preshing.com/20111007/how-to-generate-random-timings-for-a-poisson-process/
func (exe *Execution) durationTilNextRequest() time.Duration {
	v, _ := exe.Lambda.Float64()
	milliseconds := time.Duration(rand.ExpFloat64()/v*float64(time.Millisecond)) * 100
	return milliseconds
}
