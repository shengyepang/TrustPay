package execution

import (
	"bytes"
	"consensus/common/pkg/log"
	"consensus/common/pkg/request"
	"fmt"
	"github.com/jinzhu/gorm"
	d "github.com/shopspring/decimal"
	"strconv"
	"strings"
)

type sample struct {
	ID         string `gorm:"primary_key"`
	Name       string
	Created    int64 // 请求开始时间
	Speculated int64 // 请求推测执行时间
	Rollback   int64 // 回滚时间
	Committed  int64 // 请求成功时间
	Aborted    int64 // 请求失败时间
}

type intermediate struct {
	Created    d.Decimal `gorm:"type:decimal"`
	Speculated d.Decimal `gorm:"type:decimal"`
	Start      int64
	End        int64
}

type result struct {
	Name         string
	AvgDuration  d.Decimal `gorm:"type:decimal"` // request to response duration in microseconds
	Throughput   d.Decimal `gorm:"type:decimal"` // committed requests per microsecond
	RollbackRate d.Decimal `gorm:"type:decimal"` // rollback request count / request total
	AbortRate    d.Decimal `gorm:"type:decimal"` // abort request count / request total
}

type credit struct {
	ID         string `gorm:"primary_key"`
	NodeID     string
	NodeCredit d.Decimal `gorm:"type:decimal"`
	BFT        bool      `gorm:"type:bool"`
}

func (exe *Execution) Collect(db *gorm.DB, servers []interface{}) {
	sampleTableName := fmt.Sprintf("%v_sample", exe.name)
	sampleTableName = strings.ReplaceAll(sampleTableName, ".", "_")
	if !db.HasTable(sampleTableName) {
		db.Table(sampleTableName).CreateTable(&sample{})
	}
	if !db.HasTable(&result{}) {
		db.CreateTable(&result{})
	}

	total := 0

	calculateResult := func(test []*request.Event) {
		samples := make([]*sample, 0)
		log.Info(exe.name + " Start Save to DB")
		maps := make(map[string]*sample)
		for _, evt := range test {
			v := &sample{}
			if s, y := maps[evt.ID]; !y {
				maps[evt.ID] = v
				samples = append(samples, v)
			} else {
				v = s
			}

			switch evt.Status {
			case request.Created:
				v.Created = evt.Timestamp
			case request.Speculate:
				v.Speculated = evt.Timestamp
			case request.RollBack:
				v.Rollback = evt.Timestamp
			case request.Aborted:
				v.Aborted = evt.Timestamp
			case request.Committed:
				v.Committed = evt.Timestamp
			}
		}
		BatchSave(db, samples, sampleTableName, strings.ReplaceAll(exe.name, ".", "_"))
		var (
			r                                   result
			temp                                intermediate
			total, rollback, aborted, committed int64
		)

		r.Name = strings.ReplaceAll(exe.name, ".", "_")

		// request duration 客户端延迟
		q := fmt.Sprintf("SELECT avg(speculated-created) as speculated from %v where speculated != 0 and created != 0 and committed != 0", sampleTableName)
		db.Raw(q).Scan(&temp)
		r.AvgDuration = temp.Speculated

		// total
		db.Table(sampleTableName).Where("created != 0").Count(&total)
		// rollback count
		db.Table(sampleTableName).Where("\"rollback\" != 0").Count(&rollback)
		// abort count
		db.Table(sampleTableName).Where("aborted != 0").Count(&aborted)
		// committed count
		db.Table(sampleTableName).Where("committed != 0").Count(&committed)
		// start and end of all requests
		//db.Table(sampleTableName).Where("committed != 0").Select("0 as start,sum(committed-created) as end").Scan(&temp)
		db.Table(sampleTableName).Select("min(created) as start,max(max(committed),max(aborted)) as end").Scan(&temp)

		// rollback rate, abort rate
		if total == 0 {
			r.RollbackRate = d.Zero
			r.AbortRate = d.Zero
			r.Throughput = d.Zero
		} else {
			r.RollbackRate = d.NewFromInt(rollback).Div(d.NewFromInt(total))
			r.AbortRate = d.NewFromInt(aborted).Div(d.NewFromInt(total))
			if (temp.End - temp.Start) == 0 {
				r.Throughput = d.Zero
			} else {
				r.Throughput = d.NewFromInt(committed).Div(d.NewFromInt(temp.End - temp.Start))
			}
		}

		db.Create(&r)
	}

	tests := make([]*request.Event, 0)
	RollBackMap := make(map[string]bool)
	SpeculateMap := make(map[string]*request.Event)
	for {
		select {
		case evt := <-exe.reportCh:
			switch evt.Status {
			case request.RollBack:
				if _, ok := RollBackMap[evt.ID]; !ok {
					tests = append(tests, evt)
					RollBackMap[evt.ID] = true
				}
			case request.Created:
				tests = append(tests, evt)
			case request.Credit:
				sampleTableNamecredit := fmt.Sprintf("%v_credit", exe.name)
				sampleTableNamecredit = strings.ReplaceAll(sampleTableNamecredit, ".", "_")
				if !db.HasTable(sampleTableNamecredit) {
					// 创建信用检测表
					db.Table(sampleTableNamecredit).CreateTable(credit{ID: evt.ID})
				}
				//value,_:=d.NewFromString(evt.Data["credit"].(string))
				sql := "insert into " + sampleTableNamecredit + " (`id`,`node_id`,`node_credit`,`bft`) values" +
					fmt.Sprintf("('%s','%s','%s',", evt.ID+"_"+evt.Data["nodeid"].(string), evt.Data["nodeid"].(string), evt.Data["credit"].(string))
				if bft := evt.Data["bft"]; bft.(bool) {
					sql += "1);"
				} else {
					sql += "0);"
				}
				err := db.Exec(sql).Error
				if err != nil {
					log.Error(err.Error())
				}
			case request.Speculate:
				if _evt, ok := SpeculateMap[evt.ID]; !ok {
					SpeculateMap[evt.ID] = evt
				} else {
					if _evt.Timestamp > evt.Timestamp {
						SpeculateMap[evt.ID] = evt
					}
				}
			case request.Aborted, request.Committed:
				total++
				tests = append(tests, evt)
				log.Info("平台还需要接收" + strconv.Itoa(exe.requestCount-total) + " 条消息,总共需要 " + strconv.Itoa(exe.requestCount) + " 条消息")
				if total == exe.requestCount {
					for _, _evt := range SpeculateMap {
						tests = append(tests, _evt)
					}
					calculateResult(tests)
					// 释放内存
					tests = nil
					return
				}
			}
		}
	}
}

// BatchSave 批量插入数据
func BatchSave(db *gorm.DB, emps []*sample, sampleTableName, ExecutionName string) error {
	var buffer bytes.Buffer
	sql := "insert into " + sampleTableName + " (`id`,`Name`,`Created`,`Speculated`,`Rollback`,`Committed`,`Aborted`) values"
	if _, err := buffer.WriteString(sql); err != nil {
		return err
	}
	for i, e := range emps {
		if i == len(emps)-1 {
			buffer.WriteString(fmt.Sprintf("('%d','%s','%d','%d','%d','%d','%d');", i, ExecutionName, e.Created, e.Speculated, e.Rollback, e.Committed, e.Aborted))
		} else {
			buffer.WriteString(fmt.Sprintf("('%d','%s','%d','%d','%d','%d','%d'),", i, ExecutionName, e.Created, e.Speculated, e.Rollback, e.Committed, e.Aborted))
		}
	}
	exec := buffer.String()
	return db.Exec(exec).Error
}
