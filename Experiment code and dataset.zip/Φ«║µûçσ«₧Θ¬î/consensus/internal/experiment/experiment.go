package experiment

import (
	"consensus/common/pkg/log"
	"consensus/common/pkg/network"
	"consensus/common/pkg/node"
	"consensus/internal/env"
	"consensus/internal/execution"
	"consensus/internal/variate"
	"fmt"
	"github.com/jinzhu/gorm"
)

// Run carry out an experiment
func Run(name string, v variate.Variate, e *env.Env, db *gorm.DB, ClientType, ServerType string, TestParams map[string]interface{}, onlyone bool) {
	sugar := log.New()
	if name == "" {
		fmt.Println("experiment name can't be empty")
		return
	}

	// loop and execute the experiment
	for i := 1; ; i++ {
		name := fmt.Sprintf("%v_%v", name, v.String())
		// 创建单个实验测试的所有执行配置
		exe := execution.New(e, name)
		done := v.BlendIn(exe)

		v.String()
		//  execution
		sugar.Debugf("------------ %v ------------", name)
		sugar.Debug(exe)
		sugar.Debugf("------------ %v ------------", name)
		_ = sugar.Sync()
		// (暂不考虑信誉)
		// reibft共识算法创建共识委员会
		//if v.Name() == env.CommitteeNo {
		//	TestParams[env.CommitteeNo] = exe.CommitteeNo
		//	if int64(i) == e.ServerNO {
		//		sugar.Errorf("委员会数量必须小于服务节点数量")
		//		return
		//	}
		//}
		// 1. create clients and servers
		sugar.Debug("spawn algorithm related nodes and network")
		clients, servers, net := exe.Spawn(ClientType, ServerType, TestParams)

		// 2. start manipulating clients and monitoring result
		sugar.Info("start execution")
		exe.Start(clients, servers, db)

		// 3. wait til test execution done
		sugar.Debug("execution complete")
		cleanup(clients, servers, net)
		clients = nil
		servers = nil
		net = nil
		if done {
			sugar.Debug("experiment complete")
			return
		}
		// 单次循环测试
		if onlyone {
			break
		}
	}
}

// cleanup all the resources created for an execution
func cleanup(clients []interface{}, servers []interface{}, net *network.Network) {
	sugar := log.New()
	defer sugar.Sync()

	// stop clients
	sugar.Info("stop clients")
	for _, c := range clients {
		c.(node.ImpClient).Destroy()
	}

	// stop servers
	sugar.Info("stop servers")
	for _, s := range servers {
		s.(node.ImpServer).Destroy()
	}

	// bring down network
	sugar.Info("stop network")
	net.Down()
}
