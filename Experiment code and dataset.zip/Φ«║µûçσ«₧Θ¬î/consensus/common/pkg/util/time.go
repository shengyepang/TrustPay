package util

import (
	"math/rand"
	"time"
)

// Timestamp get a timestamp of current time, microseconds
// 获取微秒的时间戳
func Timestamp() int64 {
	return TimestampOf(time.Now())
}

// Timestamp get a timestamp of specified time, microseconds
func TimestampOf(t time.Time) int64 {
	return t.UnixNano() / 1e3
}

func RandFloats(min, max float64, n int) []float64 {
	rand.Seed(time.Now().UnixNano())
	res := make([]float64, n)
	for i := range res {
		res[i] = min + rand.Float64()*(max-min)
	}
	return res
}
