package message

type Message struct {
	Type      string      `json:"type"`       // 消息类型
	SendAt    int64       `json:"send_at"`    // 发送时间戳（毫秒数）
	ClientID  string      `json:"client_id"`  // 客户端ID
	SenderID  string      `json:"sender_id"`  // 发送者ID
	TargetID  string      `json:"target_id"`  // 接收者ID 后期删除
	TargetIDS []string    `json:"target_ids"` // 接收者ID数量
	RequestID string      `json:"request_id"` // 关联请求ID
	Payload   interface{} `json:"payload"`    // 消息内容
}
