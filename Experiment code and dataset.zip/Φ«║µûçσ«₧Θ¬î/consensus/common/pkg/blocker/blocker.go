package blocker

import (
	"sync"
)

type Blocker struct {
	tolerance       uint
	mut             sync.Mutex
	misbehaveRecord map[string]uint
}

func New(tolerance uint) *Blocker {
	return &Blocker{
		tolerance:       tolerance,
		mut:             sync.Mutex{},
		misbehaveRecord: make(map[string]uint),
	}
}

// Misbehave increase the misbehave count of a node
func (bl *Blocker) Misbehave(id string) {
	bl.mut.Lock()
	defer bl.mut.Unlock()

	if _, ok := bl.misbehaveRecord[id]; ok {
		bl.misbehaveRecord[id]++
	} else {
		bl.misbehaveRecord[id] = 1
	}
}

// MisbehaveCount reads the misbehave count of a node
func (bl *Blocker) MisbehaveCount(id string) uint {
	bl.mut.Lock()
	defer bl.mut.Unlock()

	if _, ok := bl.misbehaveRecord[id]; ok {
		return bl.misbehaveRecord[id]
	} else {
		return 0
	}
}

// Blocked check whether the node was blocked
func (bl *Blocker) Blocked(id string) bool {
	bl.mut.Lock()
	defer bl.mut.Unlock()

	if _, ok := bl.misbehaveRecord[id]; ok {
		return bl.misbehaveRecord[id] >= bl.tolerance
	} else {
		return false
	}
}
