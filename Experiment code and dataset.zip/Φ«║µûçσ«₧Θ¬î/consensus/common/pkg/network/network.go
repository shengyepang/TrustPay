package network

import (
	"consensus/common/pkg/ImpNetwork"
	"consensus/common/pkg/geography"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/node"
	"consensus/common/pkg/util"
	"context"
	"fmt"
	d "github.com/shopspring/decimal"
	"sync"
	"time"
)

const (
	Broadcast_All    = "all"
	Broadcast_Server = ""
)

type Network struct {
	geoType string                 // simulate transportation delay
	nodes   map[string]interface{} // map of nodes that construct this network
	cancel  context.CancelFunc     // Down stop network related goroutines
	ctx     context.Context        // context for cancellation
	isStart bool
}

var NetTimeStart float64
var NetTimeEnd float64

func New(nodes []interface{}, geoType string) *Network {
	ctx, cancel := context.WithCancel(context.Background())
	net := &Network{
		geoType: geoType,
		// TODO channel buffer size maybe multiples of the total node number
		nodes:   make(map[string]interface{}),
		cancel:  cancel,
		ctx:     ctx,
		isStart: true,
	}
	geo := geography.New(geoType, len(nodes)/5)
	for _, nn := range nodes {
		n := nn.(node.ImpNode)
		// fill in nodes
		net.nodes[n.GetID()] = n
		n.OutputFunction(interface{}(net).(ImpNetwork.ImpNet))
		// set location
		n.Locate(geo.RandomLocation())
	}

	// handle new message
	return net
}

// Down destroy network
func (net *Network) Down() {
	net.SetStart()
	// stop network goroutines
	net.cancel()
}

func (net *Network) SetStart() {
	rmut.Lock()
	net.isStart = false
	rmut.Unlock()
}

func (net *Network) GetStart() bool {
	rmut.RLock()
	defer rmut.RUnlock()
	return net.isStart
}

var rmut sync.RWMutex

func (net *Network) Up(msg *message.Message) {
	if !net.GetStart() {
		return
	}
	sender := net.nodes[msg.SenderID]
	if len(msg.TargetIDS) > 0 {
		maps := make(map[string]bool)
		for _, m := range msg.TargetIDS {
			maps[m] = true
		}
		for _, n := range net.nodes {
			if _, y := maps[n.(node.ImpNode).GetID()]; y {
				go net.dispatch(sender, n, *msg)
			}
		}
	} else {
		switch msg.TargetID {
		case Broadcast_Server:
			// broadcast
			for _, n := range net.nodes {
				if !net.GetStart() {
					return
				}
				// skip different node type 先删除 保证全网广播 是 广播给所有节点
				if (sender.(node.ImpNode).GetType() == node.Server && sender.(node.ImpNode).GetType() != n.(node.ImpNode).GetType()) || (sender.(node.ImpNode).GetType() == node.Client && sender.(node.ImpNode).GetType() == n.(node.ImpNode).GetType()) {
					continue
				}
				go net.dispatch(sender, n, *msg)
			}
			break
		case Broadcast_All:
			for _, n := range net.nodes {
				if !net.GetStart() {
					return
				}
				go net.dispatch(sender, n, *msg)
			}
			break
		default:
			if n, ok := net.nodes[msg.TargetID]; ok {
				go net.dispatch(sender, n, *msg)
			} else {
				err := fmt.Errorf("Sending message to a unknown node:\nnetwork: %v\nmessage: %v\n", net, msg)
				log.Panic(err)
			}
		}
	}
}

// dispatch message to target node, simulate delay if necessary
func (net *Network) dispatch(sender, target interface{}, msg message.Message) {

	var t *time.Timer
	var t1 *time.Timer
	select {
	// watch cancellation
	case <-net.ctx.Done():
		// cancel timer if necessary
		if t != nil {
			t.Stop()
		}
		if t1 != nil {
			t1.Stop()
		}
		return
	// dispatch message
	default:
		// skip distance based delay simulation if not necessary
		if net.geoType == geography.Local {
			MaxNetWork := util.RandFloats(NetTimeStart, NetTimeEnd, 1)
			t1 = time.AfterFunc(time.Duration(MaxNetWork[0])*1000*time.Millisecond, func() {
				target.(node.ImpNode).HandleMessage(msg)
			})
			return
		}

		// in meters
		distance := sender.(node.ImpNode).Distance(target.(node.ImpNode)).Floor()

		// simulate delay only if there is a distance
		if !distance.Equals(d.Zero) {
			delay := geography.DelayByDistance(distance)
			t = time.AfterFunc(delay, func() {
				target.(node.ImpNode).HandleMessage(msg)
			})
		} else {
			target.(node.ImpNode).HandleMessage(msg)
		}
	}
}
