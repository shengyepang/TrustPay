package node

import "consensus/common/pkg/request"

type ImpServer interface {
	ImpNode
	Init(id string, number int, reportCh chan<- *request.Event) // 服务节点初始化
	GetNode() *Node                                             // 获取服务节点
	Destroy()
	SetNodes([]interface{}, []interface{})
}

type ServerBase struct {
	*Node
}

func NewServerBase(id string, t NodeType) *ServerBase {
	n := &ServerBase{
		Node: New(id, t),
	}
	return n
}
