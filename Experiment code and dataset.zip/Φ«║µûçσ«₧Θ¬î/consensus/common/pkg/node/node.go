package node

import (
	"consensus/common/pkg/ImpNetwork"
	"consensus/common/pkg/geography"
	"consensus/common/pkg/message"
	"context"
	d "github.com/shopspring/decimal"
	"sync"
)

type NodeType uint8

const (
	Client NodeType = iota
	Server
)

// node is the embedded interface for Node
type ImpNode interface {
	// Distance Calculate the distance between two nodes in meters
	Distance(another ImpNode) d.Decimal //模拟两个节点之间距离的接口
	// Output set the output message channel for the node
	Output(chan<- message.Message)        //服务端需要给测试平台发送消息用到的
	OutputFunction(net ImpNetwork.ImpNet) //服务端需要给测试平台发送消息用到的
	// Locate set the simulate geography location longitude and latitude
	Locate(longitude, latitude d.Decimal) //经纬度
	// Send message
	Send(msg message.Message) //节点之间发送消息
	// Destroy the node
	Destroy()                             //释放内存
	GetID() string                        //获取节点ID
	GetType() NodeType                    //
	GetLocate() (d.Decimal, d.Decimal)    //获取节点经纬度坐标
	SetTestParams(map[string]interface{}) //设置自定义测试传递参数
	HandleMessage(msg message.Message)
	//Reitype(num int) //设置委员节点的微电网号
}

// node is the actor of all actions described in the distributed algorithm
type Node struct {
	ID        string                 // node ID
	Type      NodeType               // node type
	outputCh  chan<- message.Message // message sending channel
	outputFun ImpNetwork.ImpNet
	longitude d.Decimal          // longitude
	latitude  d.Decimal          // latitude
	Byzantine bool               // 用于测试平台设置Byzantine
	RMu       sync.RWMutex       //  *deadlock.RWMutex 读写锁,避免同时操作数据
	Mu        sync.Mutex         //  *deadlock.Mutex
	Cancel    context.CancelFunc // context cancel function
	Ctx       context.Context    // context for cancellation
	Wg        sync.WaitGroup
}

// New creates a new node, and monitor new messages
func New(id string, t NodeType) *Node {
	ctx, cancel := context.WithCancel(context.Background())
	n := &Node{
		ID:        id,
		Type:      t,
		Byzantine: false,
		//RMu:       new(deadlock.RWMutex),
		//Mu:        new(deadlock.Mutex),
		Cancel: cancel,
		Ctx:    ctx,
	}
	return n
}

// Distance Calculate the distance between two nodes in meters
func (node *Node) Distance(another ImpNode) d.Decimal {
	longitude, latitude := another.GetLocate()
	return geography.Distance(node.longitude, node.latitude, longitude, latitude)
}

// Output
func (node *Node) Output(oc chan<- message.Message) {
	node.outputCh = oc
}
func (node *Node) OutputFunction(net ImpNetwork.ImpNet) {
	node.outputFun = net
}

func (node *Node) GetType() NodeType {
	return node.Type
}

// Locate
func (node *Node) Locate(longitude, latitude d.Decimal) {
	node.longitude = longitude
	node.latitude = latitude
}
func (node *Node) GetLocate() (longitude, latitude d.Decimal) {
	longitude = node.longitude
	latitude = node.latitude
	return
}

func (node *Node) HandleMessage(msg message.Message) {

}

// Destroy the client and stop related goroutines
func (node *Node) Destroy() {
	node.Cancel()
	node.Wg.Wait()
}

func (node *Node) GetID() string {
	return node.ID
}

// Send message
func (node *Node) Send(msg message.Message) {
	if node.outputCh != nil {
		node.outputCh <- msg
	}
	if node.outputFun != nil {
		node.outputFun.Up(&msg)
	}
}

func (node *Node) SetTestParams(param map[string]interface{}) {

}
