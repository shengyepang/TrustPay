package node

import (
	"consensus/common/pkg/request"
)

type ImpClient interface {
	ImpNode
	// 客户端发送消息接口
	Request(op interface{}, id string)
	// 客户端初始化接口
	Init(id string, tolerance uint, servers []interface{}, reportCh chan<- *request.Event)
	// 获取父类接口
	GetNode() *Node
	// 停止数据和网络接口
	Destroy()
	// 客户端节点数量
	SetClients(Clients []interface{})
	// 获取测试数据
	GetRequestOP() interface{}
	// 获取参与共识的服务器节点
	GetJoinConsensusNodes() []interface{}
}

type ClientBase struct {
	*Node
}

func (c *ClientBase) SetClients(clients []interface{}) {

}

func (c *ClientBase) GetJoinConsensusNodes() []interface{} {
	return nil
}

func NewClientBase(id string, t NodeType) *ClientBase {
	n := &ClientBase{
		Node: New(id, t),
	}
	return n
}
