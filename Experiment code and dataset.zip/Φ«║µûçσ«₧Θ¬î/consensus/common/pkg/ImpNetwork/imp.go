package ImpNetwork

import "consensus/common/pkg/message"

type ImpNet interface {
	Up(msg *message.Message)
}
