package request

// Status defines the status of a request for any consensus algorithm
type Status int

const (
	Created   Status = iota
	Speculate        // ezPnyx speculatively applied
	Committed        // consensus made
	RollBack         // rollback of an applied request
	Aborted          // abort request
	Credit
)

// Event define a request status change event
type Event struct {
	Status    Status // status of the request
	Timestamp int64  // timestamp in milliseconds
	ID        string // request id
	ClientID  string // related client id
	Data map[string]interface{}
}
