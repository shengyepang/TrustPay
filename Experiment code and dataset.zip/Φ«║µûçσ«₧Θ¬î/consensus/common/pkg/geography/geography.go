package geography

import (
	"crypto/rand"
	d "github.com/shopspring/decimal"
	"math/big"
	"time"
)

const (
	regionRadius      = 10 * 1000  // 10 kilometers
	minRegionDistance = 200 * 1000 // 200 kilometers

	// geography types of the network
	Local  string = "local"  // distance between nodes are ignored
	Region        = "region" // nodes are scattered inside one region
	Global        = "global" // nodes are scattered all over the globe, multiple regions
)

type Geography struct {
	geoType string
	regions []*region
}

type region struct {
	longitude d.Decimal
	latitude  d.Decimal
}

func New(geoType string, regionCount int) *Geography {
	var regions []*region
	min := d.NewFromInt(minRegionDistance) // distance minimum between two region center

	switch geoType {
	case Global:
		// create multiple regions, notice regionTotal cannot be too large
		for i := 0; i < regionCount; i++ {
			r := pickRegion(regions, min)
			regions = append(regions, r)
		}
	case Region:
		regions = append(regions, newRegion())
	case Local:
	}

	return &Geography{
		geoType: geoType,
		regions: regions,
	}
}

func (g *Geography) RandomLocation() (longitude, latitude d.Decimal) {
	switch g.geoType {
	case Global:
		regionIndex := randInt(int64(len(g.regions)))
		region := g.regions[regionIndex]
		return region.randomLocation()
	case Region:
		return g.regions[0].longitude,g.regions[0].latitude
	case Local:
		return d.Zero, d.Zero
	default:
		return d.Zero, d.Zero
	}
}

// DelayByDistance calculate the duration delayed base on distance
func DelayByDistance(distance d.Decimal) time.Duration {
	// 1 microsecond delay per meter
	return time.Duration(distance.Ceil().IntPart()/10) * time.Microsecond
}

func newRegion() *region {
	return &region{
		longitude: randFloat(-180, 180),
		latitude:  randFloat(-90, 90),
	}
}

// randomLocation generate a location randomly inside the region
func (r *region) randomLocation() (longitude, latitude d.Decimal) {
	radius := d.NewFromInt(randInt(regionRadius))
	angle := d.NewFromInt(randInt(360))

	// x = centerX + radius * cos(angle)
	// y = centerY + radius * sin(angle)
	longitude = r.longitude.Add(angle.Cos().Mul(radius))
	latitude = r.latitude.Add(angle.Sin().Mul(radius))

	return
}

// pickRegion create a new region far away enough from every other region
func pickRegion(regions []*region, min d.Decimal) *region {
	regionCandidate := newRegion()

	for _, reg := range regions {
		// if distance too small, re-pick
		if Distance(regionCandidate.longitude, regionCandidate.latitude, reg.longitude, reg.latitude).LessThanOrEqual(min) {
			return pickRegion(regions, min)
		}
	}

	return regionCandidate
}

func randInt(max int64) int64 {
	i, _ := rand.Int(rand.Reader, big.NewInt(max))
	return i.Int64()
}

func randFloat(min, max float64) d.Decimal {
	_min := d.NewFromFloat(min)
	_max := d.NewFromFloat(max)
	intMax := _max.Sub(_min).Mul(d.NewFromInt(1e6))
	i, _ := rand.Int(rand.Reader, intMax.BigInt())
	return d.NewFromBigInt(i, -5)
}
