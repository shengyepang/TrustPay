package geography

import (
	d "github.com/shopspring/decimal"
	"math"
)

var (
	earthRadius,
	pi,
	one, two, three, four d.Decimal
)

func init() {
	// Earth's mean radius in meters
	earthRadius = d.NewFromInt(6371e3)

	// constant π
	pi = d.NewFromFloat(math.Pi)

	one = d.NewFromInt(1)
	two = d.NewFromInt(2)
	three = d.NewFromInt(3)
	four = d.NewFromInt(4)
}

// Distance Calculate the distance between two locations in meters
func Distance(longitudeA, latitudeA, longitudeB, latitudeB d.Decimal) d.Decimal {
	if latitudeA.Equals(d.Zero) && longitudeA.Equal(d.Zero) && longitudeB.Equal(d.Zero) && latitudeB.Equal(d.Zero) {
		return d.Zero
	}

	latDiffRadian := degrees2radians(latitudeB.Sub(latitudeA))
	longDiffRadian := degrees2radians(longitudeB.Sub(longitudeA))
	aLatRadian := degrees2radians(latitudeA)
	bLatRadian := degrees2radians(latitudeB)

	b := latDiffRadian.Div(two).Sin().Pow(two).Add(
		aLatRadian.Cos().Mul(bLatRadian.Cos()).Mul(
			longDiffRadian.Div(two).Sin().Pow(two),
		),
	)

	c := two.Mul(
		atan2(
			squareRoot(b),
			squareRoot(one.Sub(b)),
		),
	)

	return earthRadius.Mul(c)
}

// Calculate longitude/latitude degrees to radian
func degrees2radians(degrees d.Decimal) d.Decimal {
	return degrees.Mul(d.NewFromFloat(math.Pi)).Div(d.NewFromInt(180))
}

func squareRoot(decimal d.Decimal) d.Decimal {
	bigInt := decimal.Coefficient()
	bigInt.Sqrt(bigInt)
	return d.NewFromBigInt(bigInt, decimal.Exponent())
}

func atan2(y, x d.Decimal) d.Decimal {
	// special cases
	switch {
	case y.Equals(d.Zero):
		if x.GreaterThanOrEqual(d.Zero) && x.IsPositive() {
			return copySign(d.Zero, y)
		}
		return copySign(pi, y)
	case x.Equals(d.Zero):
		return copySign(pi.Div(two), y)
	case isInf(x, 0):
		if isInf(x, 1) {
			switch {
			case isInf(y, 0):
				return copySign(pi.Div(four), y)
			default:
				return copySign(d.Zero, y)
			}
		}
		switch {
		case isInf(y, 0):
			return copySign(three.Mul(pi).Div(four), y)
		default:
			return copySign(pi, y)
		}
	case isInf(y, 0):
		return copySign(pi.Div(two), y)
	}

	// Call atan and determine the quadrant.
	q := y.Div(x).Atan()
	if x.LessThan(d.Zero) {
		if q.LessThanOrEqual(d.Zero) {
			return q.Add(pi)
		}
		return q.Sub(pi)
	}
	return q
}

func copySign(target, source d.Decimal) d.Decimal {
	i64 := target.IntPart()
	return d.New(i64*int64(source.Sign()), 1)
}

// isInf reports whether f is an infinity, according to sign.
// copied from math/bits.go IsInf
func isInf(decimal d.Decimal, sign int) bool {
	intPart := decimal.IntPart()
	return sign >= 0 && intPart > math.MaxInt64 || sign <= 0 && intPart < -math.MaxInt64
}
