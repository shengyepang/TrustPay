package Message

import "consensus/REIBFT/Model"

type Type uint8

const (
	Request Type = iota
	PrePrepare
	Prepare
	Commit
	Aborted
	PrePrepareAborted
	Finished
	Credit
)

func (mt Type) String() string {
	switch mt {
	case Request:
		return "Request"
	case PrePrepare:
		return "PrePrepare"
	case Prepare:
		return "Prepare"
	case Commit:
		return "Commit"
	case Aborted:
		return "Aborted"
	case Finished:
		return "Finished"
	case Credit:
		return "Credit"
	case PrePrepareAborted:
		return "PrePrepareAborted"
	default:
		return "Unknown"
	}
}

type MsgState byte

const (
	Msg_RePrepare_Success MsgState = iota
	Msg_RePrepare_Fail
	Msg_RePrepare_Nomal
)

type Message_State struct {
	SendID      string                // 消息发送节点
	Message     *Model.RequestMessage // 消息体
	HashMessage string                // 请求消息的hash
	Deadline    int64
}
