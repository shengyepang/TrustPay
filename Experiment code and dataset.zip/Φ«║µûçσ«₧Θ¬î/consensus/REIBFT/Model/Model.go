package Model

import "consensus/REIBFT/Block"

type RequestMessage struct {
	VDFSeed    [32]byte
	VDF        [516]byte
	Committees []interface{}
	Nodei      interface{}
	Block      *Block.Block
}
