package Credit

import "math"

const (
	Alpha = 6
	Beta  = 0.02
	Pi    = 5
	Rho   = 0.48
	Rmin  = 0.2
)

type Credit_Node struct {
	NodeID string // 服务端ID
	Credit Credit
}

type Credit struct {
	Value float64 // 信用值
}

// 信誉增加
/*
参数说明：
R1i : 参与共识的节点i的当前信誉值
riAdd : 节点i参与过的所有共识实例的成功率
ti : 距离节点i上一次发生共识信用降低的时间间隔
GammaSet : 设置的Gamma值，之前为0.05，后期可能修改
RcColl : 区块委员会的信用分数集合
isCreatedNode : 是否为区块生成节点
*/
func R1iAdd(R1i float64, riAdd float64, ti float64, GammaSet float64, RcColl []float64, isCreatedNode bool) (R1iNew float64) {

	// math.Exp()  // 以e为底的指数函数  e的x次幂
	// func Pow(x, y float64) float64  // x的幂函数
	y := -Beta * ti
	ebt := math.Pow(10, y)
	ind := -Alpha * ((riAdd * (1 - ebt)) / ((100 * R1i) * (100 * R1i)))
	R1iAddValue := 0.00

	if R1i >= Rmin {
		Gamma := 0.00
		if isCreatedNode {
			Gamma = GammaSet
		} else {
			Gamma = 0.00
		}

		// 求Rc
		additionResult := 0.00
		for _, value := range RcColl {
			additionResult += value
		}
		Rc := additionResult / float64(len(RcColl))

		R1iAddValue = 1 - math.Pow(Pi, ind) + (Gamma * Rc)

	} else {
		R1iAddValue = 0.00
	}

	maxValue := math.Max(R1i+R1iAddValue, 0)
	R1iNew = math.Min(maxValue, 1)

	return R1iNew

}

// 信誉减少
/*
参数说明：
R1i : 参与共识的节点i的当前信誉值
riSubtract : 节点i参与过的所有共识实例的失败率
ti : 距离节点i上一次发生共识信用降低的时间间隔
GammaSet : 设置的Gamma值，之前为0.05，后期可能修改
RcColl : 区块委员会的信用分数集合
isCreatedNode : 是否为区块生成节点
*/
func R1iSubtract(R1i float64, riSubtract float64, ti float64, GammaSet float64, RcColl []float64, isCreatedNode bool) (R1iNew float64) {

	y := -Beta * ti
	ebt := math.Pow(10, y)
	ind := Alpha * ((riSubtract * (1 - ebt)) / ((100 * (1 - R1i)) * (100 * (1 - R1i))))
	R1iSubtractValue := 0.00

	if R1i >= Rmin {
		Gamma := 0.00
		if isCreatedNode {
			Gamma = GammaSet
		} else {
			Gamma = 0.00
		}
		// 求Rc
		additionResult := 0.00
		for _, value := range RcColl {
			additionResult += value
		}
		Rc := additionResult / float64(len(RcColl))

		R1iSubtractValue = math.Pow(ind, Rho) + Gamma*(1-Rc)
	} else {
		R1iSubtractValue = 0.00
	}

	maxValue := math.Max(R1i-R1iSubtractValue, 0)
	R1iNew = math.Min(maxValue, 1)

	return R1iNew
}

// SuccessRate
