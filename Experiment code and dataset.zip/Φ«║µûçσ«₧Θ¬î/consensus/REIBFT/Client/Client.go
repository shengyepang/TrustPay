package Client

import (
	"consensus/REIBFT/Block"
	"consensus/REIBFT/Credit"
	TypeMessage "consensus/REIBFT/Message"
	"consensus/REIBFT/Model"
	"consensus/REIBFT/Server"
	"consensus/REIBFT/Tool"
	"consensus/REIBFT/vdf_go"
	"consensus/common/pkg/blocker"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/node"
	"consensus/common/pkg/request"
	"consensus/common/pkg/util"
	"context"
	"fmt"

	"math/rand"
	"strconv"
	"sync/atomic"
	"time"
)

//微电网属性，属于哪个微电网
type REIClienttype int

var (
	// Request超时时间
	DeadLine = 100 * 1000 * time.Millisecond
)

// 客户端节点,即发起交易的客户端
type Client struct {
	*node.ClientBase                        // 节点基础信息，在公共部分定义
	*blocker.Blocker                        // 禁用名单
	ReportCh         chan<- *request.Event  // experiment report channel 实验报道通道
	Servers          []interface{}          // 服务节点列表
	Clients          []interface{}          // 客户端节点列表
	CommitteeNo      int                    // 委员会数量
	Committees       []interface{}          // 委员会
	TestParams       map[string]interface{} // 测试平台传递的测试参数
	RequestEvent     request.Event          // 请求事件，可能是客户端发起的消息
	FishCount        uint32
	Ctx              context.Context      //用于在程序单元Goroutine之间传递运行状态
	DeadChannel      chan message.Message //消息通道
	Nodei            interface{}
	Clienttype       REIClienttype //微电网类型划分标识
}

// TODO 公共接口
// 将消息发送给测试平台
func (c *Client) HandleMessage(msgs message.Message) {
	Tool.SafeSend(c.DeadChannel, msgs)
}

func (c *Client) ListenHandlMessage(RequestID string) {
	go func() {
		for {
			select {
			case <-c.Ctx.Done():
				t := util.Timestamp()
				c.ReportCh <- &request.Event{
					Status:    request.Speculate,
					ID:        RequestID,
					Timestamp: t,
					ClientID:  c.ID,
				}
				c.ReportCh <- &request.Event{
					Status:    request.Aborted,
					ID:        RequestID,
					Timestamp: t,
					ClientID:  c.ID,
				}
				close(c.DeadChannel)
				return
			case msg := <-c.DeadChannel:
				// 处理消息通道中的消息
				switch msg.Type {
				case TypeMessage.Commit.String(): // 共识成功
					FishCount := atomic.AddUint32(&c.FishCount, 1)
					if int(FishCount) == len(c.Servers)-1 {
						c.ReportCh <- &request.Event{
							Status:    request.Speculate,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						c.ReportCh <- &request.Event{
							Status:    request.Committed,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						return
					}
				case TypeMessage.Aborted.String(): // 终止
					FishCount := atomic.AddUint32(&c.FishCount, 1)
					if int(FishCount) == len(c.Servers)-1 {
						c.ReportCh <- &request.Event{
							Status:    request.Speculate,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						c.ReportCh <- &request.Event{
							Status:    request.Aborted,
							ID:        msg.RequestID,
							Timestamp: msg.SendAt,
							ClientID:  c.ID,
						}
						return
					}
				case TypeMessage.PrePrepareAborted.String():
					t := util.Timestamp()
					c.ReportCh <- &request.Event{
						Status:    request.Speculate,
						ID:        RequestID,
						Timestamp: t,
						ClientID:  c.ID,
					}
					c.ReportCh <- &request.Event{
						Status:    request.Aborted,
						ID:        RequestID,
						Timestamp: t,
						ClientID:  c.ID,
					}
					close(c.DeadChannel)
					return
				}
			}
		}
	}()
}

func (c *Client) GetNode() *node.Node {
	return c.Node
}

//初始化客户端
func (c *Client) Init(id string, tolerance uint, servers []interface{}, reportCh chan<- *request.Event) {
	c.ClientBase = node.NewClientBase(id, node.Client)
	c.Blocker = blocker.New(tolerance)
	c.Servers = servers
	c.ReportCh = reportCh
	c.DeadChannel = make(chan message.Message, len(c.Servers))
	c.Nodei = c.GetFisrtServer() //获取服务端的首节点
}

//查询节点信用值得到对应的首节点
func (c *Client) GetFisrtServer() interface{} {
	//依据随机数生成首节点，并判断首节点信誉值是否达到基本的标准
	for true {
		num := rand.Intn(len(c.Servers))
		// 目标服务器节点的信誉值大于规定的信誉值，并且与本客户端信誉值的微电网类型相同
		if c.Servers[num].(*Server.Server).GetSafeCreditValue() > Credit.Rmin && int(c.Clienttype) == int(c.Servers[num].(*Server.Server).Servertype) {
			return c.Servers[num]
		}
	}
	return nil
	//暂定取最后一个server为i0节点
	//return (c.Servers[len(c.Servers)-1])
}

// Request create a request message with the op and send it to the best server
func (c *Client) Request(op interface{}, id string) {
	seed, vdf := c.GetVDF()
	block := op.(*Block.Block)

	RequestMessage := &Model.RequestMessage{
		VDFSeed:    seed,
		VDF:        vdf,
		Committees: c.Committees,
		Block:      block,
		Nodei:      c.Nodei,
	}

	msge := &TypeMessage.Message_State{
		Message: RequestMessage,
		SendID:  c.Nodei.(node.ImpServer).GetID(),
	}

	targetIDs := make([]string, 0)
	//目标ID为首节点的ID
	targetIDs = append(targetIDs, c.Nodei.(node.ImpServer).GetID())
	t := util.Timestamp()
	msg := &message.Message{ //消息的类型
		Type:      TypeMessage.Request.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  c.ID, //发送者
		ClientID:  c.ID,
		TargetIDS: targetIDs,
		RequestID: id,
		Payload:   msge,
	}
	// report request created
	c.ReportCh <- &request.Event{
		Status:    request.Created,
		ID:        msg.RequestID,
		Timestamp: t,
		ClientID:  c.ID,
	}
	// log.Info("客户端发送"+c.GetFisrtServer()[0])
	// send request
	c.Ctx, _ = context.WithTimeout(context.Background(), DeadLine)
	c.ListenHandlMessage(msg.RequestID)
	c.Send(*msg) //网络延迟
}

//延迟函数
func (c *Client) GetVDF() ([32]byte, [516]byte) {
	if data, y := c.TestParams["Vdf"]; y {
		if data.(string) == "1" {

			input := [32]byte{}
			rand.Read(input[:])

			vdf := vdf_go.New(20, input)
			//返回延迟函数的输出通道
			outputChannel := vdf.GetOutputChannel()

			start := time.Now()
			//
			vdf.Execute()

			duration := time.Now().Sub(start)

			log.Info(fmt.Sprintf("VDF computation finished, time spent %s", duration.String()))

			output := <-outputChannel
			return input, output

		}
	}
	return [32]byte{}, [516]byte{}
}

//破坏客户端对应的节点并停止相关的线程
func (c *Client) Destroy() {
	c.Node.Destroy()
}

// 基于实验传入的参数，在客户端中设置相应的实验参数
func (c *Client) SetTestParams(param map[string]interface{}) {
	c.TestParams = param
	c.CommitteeNo = int(param["CommitteeNo"].(int64))
	deadLine, _ := strconv.ParseFloat(param["DeadLine"].(string), 10)
	DeadLine = time.Duration(deadLine*1000) * time.Millisecond
}

//获取请求操作
func (c *Client) GetRequestOP() interface{} {
	//通过添加UUID使的id是唯一的
	id := c.GetNode().ID + " " + Tool.UUID()
	block := &Block.Block{Header: Block.BlockHeader{
		Timestamp: Tool.Timestamp(),
		ID:        Tool.UUID(),
		PreHash:   "",
	}, Body: Block.BlockBody{
		Data: map[string]interface{}{c.GetNode().ID: id},
	}}

	if _, y := c.TestParams["isConflict"]; y {
		block = &Block.Block{Header: Block.BlockHeader{
			Timestamp: Tool.Timestamp(),
			ID:        Tool.UUID(),
			PreHash:   "",
		}, Body: Block.BlockBody{
			Data: map[string]interface{}{"A": id},
		}}
	}
	return block
}

// 依据信誉值随机选取委员会节点（不包括i0节点）、
// 依据微电网的不同，选取委员会节点时应考虑节点所属的委员会
func (c *Client) GetJoinConsensusNodes() []interface{} {
	committes := make([]interface{}, 0)
	credit := make([]float64, 0)
	precommittes := make([]interface{}, 0)
	Reitype := int(c.Clienttype)
	// 随机生成节点信誉值的加成，并与信誉值相加
	for j := 0; j < len(c.Servers); j++ {
		// 从与客户端节点的微电网类型相同的服务端节点中选取共识组节点,并且共识组节点的信誉值要大约最小信誉值标准
		if Reitype == int(c.Servers[j].(*Server.Server).Servertype) && c.Servers[j].(*Server.Server).GetSafeCreditValue() > Credit.Rmin {

			// 将首节点的信誉值加成定义为-1.0
			if c.Servers[j].(node.ImpServer).GetID() == c.Nodei.(node.ImpServer).GetID() {
				credit = append(credit, -1.0)
				precommittes = append(precommittes, c.Servers[j]) //将服务端首节点添加到预共识组节点中
			} else {
				credit = append(credit, rand.Float64()+c.Servers[j].(*Server.Server).GetSafeCreditValue())
				precommittes = append(precommittes, c.Servers[j]) //将符合条件的服务端节点添加到预共识组节点中
			}
		}
	}

	maxnum := 0.0
	//记录委员会节点的坐标的数组，坐标为预共识组节点precommittes中的坐标
	arr := make([]int, c.CommitteeNo)
	//记录信誉值加成高的节点的坐标，
	for i := 0; i < c.CommitteeNo; i++ {
		maxnum = credit[0]
		arr[i] = 0
		for m := 1; m < len(credit); m++ {
			if maxnum < credit[m] {
				maxnum = credit[m]
				arr[i] = m
			}
		}
		credit[arr[i]] = -1
	}

	//依据节点坐标选举出委员会节点
	for n := 0; n < len(arr); n++ {
		svr := *(precommittes[arr[n]].(*Server.Server))

		c.Committees = append(c.Committees, svr)
		committes = append(committes, precommittes[arr[n]])
	}

	return committes
}

// 区分客户端节点的微电网类型
func (cli *Client) Reitype(num int) {
	cli.Clienttype = REIClienttype(num)
}
