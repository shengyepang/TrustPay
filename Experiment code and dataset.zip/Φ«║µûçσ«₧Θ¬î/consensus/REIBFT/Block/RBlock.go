package Block

import (
	"consensus/REIBFT/Credit"
	"sort"
)

type BlockHeader struct {
	ID        string
	Hash      string // 区块hash
	Height    int64  // 区块高度
	Timestamp int64  // 时间戳
	PreHash   string // 上一个区块Hash
}

type BlockBody struct {
	Data map[string]interface{}
}

type Block struct {
	NodeID  string               `json:"nodeid"`
	Header  BlockHeader          `json:"header"`
	Body    BlockBody            `json:"body"`
	Credits []Credit.Credit_Node `json:"credits"` // 信用值
}

type BlockSortHash struct {
	Block Block
	Hash  string
}

type BlockWrapper struct {
	block []*BlockSortHash
	by    func(p, q *BlockSortHash) bool
}

type SortBy func(p, q *BlockSortHash) bool

func (pw BlockWrapper) Len() int { // 重写 Len() 方法,返回区块排序hash的区块高度
	return len(pw.block)
}
func (pw BlockWrapper) Swap(i, j int) { // 重写 Swap() 方法，置换两个区块
	pw.block[i], pw.block[j] = pw.block[j], pw.block[i]
}
func (pw BlockWrapper) Less(i, j int) bool { // 重写 Less() 方法，
	return pw.by(pw.block[i], pw.block[j])
}

func SortPerson(blocks []*BlockSortHash, by SortBy) {
	sort.Sort(BlockWrapper{blocks, by})
}
