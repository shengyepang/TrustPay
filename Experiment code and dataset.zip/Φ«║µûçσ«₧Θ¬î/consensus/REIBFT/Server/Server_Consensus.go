package Server

import (
	TypeMessage "consensus/REIBFT/Message"
	"consensus/common/pkg/message"
)

//接收并解析消息
func (svr *Server) HandleMessage(msg message.Message) {
	switch msg.Type {
	case TypeMessage.Request.String():
		svr.HandleRequest(msg)
	case TypeMessage.PrePrepare.String():
		svr.HandlePrePrepare(msg)
	case TypeMessage.Prepare.String():
		svr.SavePrepareHandleChannel <- msg
	case TypeMessage.Commit.String():
		svr.SaveCommitHandleChannel <- msg
	}

}
