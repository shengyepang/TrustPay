package Server

import (
	TypeMessage "consensus/REIBFT/Message"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/node"
	"consensus/common/pkg/util"
	cmap "github.com/orcaman/concurrent-map"
)

func (svr *Server) HandlePrepare(msg message.Message) {
	data := msg.Payload.(*TypeMessage.Message_State)
	svr.SaveHandleMessage(msg.RequestID, data, &svr.PrepareMsgs)
	// 统计已经从不同节点接收到的本条消息的数量
	count := svr.GetHandleMessageCount(msg.RequestID, &svr.PrepareMsgs)
	// 拜占庭判断
	if count == -1 {
		log.Error("获取Prepare失败，没有找到 " + msg.RequestID + " 消息")
		return
	}
	// 此处N应该是共识组节点的数量，之后需要修改，体现区域能源互联网中微电网的内部共识、
	// 基于接受到消息的数量判断是否完成本阶段的共识
	if count == 2*svr.GetBFTCount()+1 {
		svr.PrepareConsensusSuccess(&msg)
	}
}

// 准备阶段完成后，对消息进行处理
func (svr *Server) PrepareConsensusSuccess(msg *message.Message) {
	// 当前msg.RequestID是否已经完成PrePrepare阶段
	if d, y := svr.ConsensusStatus.Get(msg.RequestID); y {
		if d.(TypeMessage.MsgState) == TypeMessage.Msg_RePrepare_Fail {
			log.Info("已经完成")
			return
		}
	}

	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_RePrepare_Success)
	//log.Info(svr.ID+" "+ msg.RequestID+" Prepare共识成功")
	if !svr.PrepareMsgs.Has(msg.RequestID) {
		return
	}
	data := msg.Payload.(*TypeMessage.Message_State)
	t := util.Timestamp()
	newmsg := &message.Message{ //消息的类型
		Type:     TypeMessage.Commit.String(), //根据具体的算法单独定义，
		SendAt:   t,
		SenderID: svr.ID, //发送者
		ClientID: msg.ClientID,
		// 此处不止要发给共识委员会节点，也要发送给其他的服务器节点，以他们同步共识
		TargetIDS: svr.BroadCastToAllNode(), // 定义消息接受节点
		RequestID: msg.RequestID,
		Payload:   data,
	}
	svr.Send(*newmsg) //网络延迟
}

// 保存收到的消息到本节点
func (svr *Server) SaveHandleMessage(requestid string, msg *TypeMessage.Message_State, Map *cmap.ConcurrentMap) {
	// 本条请求消息已经存在缓存列表（已经从其他节点出收到过）
	if data, y := Map.Get(requestid); y {
		data = append(data.([]*TypeMessage.Message_State), msg)
		Map.Set(requestid, data)
	} else { // 本条请求消息第一次收到
		arrays := make([]*TypeMessage.Message_State, 0)
		arrays = append(arrays, msg)
		Map.Set(requestid, arrays)
	}
}

// 获取收到的消息数量
func (svr *Server) GetHandleMessageCount(requestid string, Map *cmap.ConcurrentMap) int {
	if data, y := Map.Get(requestid); y {
		return len(data.([]*TypeMessage.Message_State))
	}
	return -1
}

// 获取所有的服务器节点的ID列表
func (svr *Server) BroadCastToAllNode() []string {
	nodes := make([]string, 0)
	for _, _node := range svr.Servers {
		nodes = append(nodes, _node.(node.ImpServer).GetID())
	}
	return nodes
}
