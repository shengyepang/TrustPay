package Server

import (
	"consensus/REIBFT/Block"
	"consensus/REIBFT/Credit"
	TypeMessage "consensus/REIBFT/Message"
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
)

func (svr *Server) CreditSubtract(msg message.Message, isCreatedNode bool, R1i float64) float64 {
	/*
	   参数说明：
	   R1i : 参与共识的节点i的当前信誉值
	   riSubtract : 节点i参与过的所有共识实例的失败率
	   ti : 距离节点i上一次发生共识信用降低的时间间隔
	   GammaSet : 设置的Gamma值，之前为0.05，后期可能修改
	   RcColl : 区块委员会的信用分数集合
	   isCreatedNode : 是否为区块生成节点
	*/

	data := msg.Payload.(*TypeMessage.Message_State)
	requestMsg := data.Message
	riSubtract := 0.00
	if (svr.GetConsensusSuccessCount() + svr.GetConsensusFailCount()) != 0 {
		riSubtract = float64(svr.GetConsensusSuccessCount() / (svr.GetConsensusSuccessCount() + svr.GetConsensusFailCount()))
	} else { // 第一次共识  成功率为1  失败率为0
		riSubtract = 0.00
	}

	tNow := util.Timestamp()
	ti := float64(tNow - svr.ConsensusFailTimeStamp) // 直接减
	GammaSet := svr.TestParams["Gamma"].(float64)

	RcColl := svr.GetRcColl(requestMsg.Committees)

	// R1iSubtract(R1i float64, riSubtract float64, ti float64, GammaSet float64, RcColl []float64, isCreatedNode bool) (R1iNew float64)
	//减少节点的信誉值
	CreditNew := Credit.R1iSubtract(R1i, riSubtract, ti, GammaSet, RcColl, isCreatedNode)

	return CreditNew
}

func (svr *Server) GetRcColl(Committees []interface{}) []float64 {
	RcColl := make([]float64, 0)
	for _, _node := range Committees {
		var s Server
		s = _node.(Server)
		creditValue := s.GetSafeCreditValue() // 每个值都是初始0.5
		RcColl = append(RcColl, creditValue)
	}
	return RcColl
}

//
func (svr *Server) CreditAdd(msg message.Message, isCreatedNode bool, R1i float64) float64 {
	/*
	   参数说明：
	   R1i : 参与共识的节点i的当前信誉值
	   riAdd : 节点i参与过的所有共识实例的成功率
	   ti : 距离节点i上一次发生共识信用降低的时间间隔
	   GammaSet : 设置的Gamma值，之前为0.05，后期可能修改
	   RcColl : 区块委员会的信用分数集合
	   isCreatedNode : 是否为区块生成节点
	*/
	data := msg.Payload.(*TypeMessage.Message_State)
	requestMsg := data.Message

	riAdd := 0.00
	if (svr.GetConsensusSuccessCount() + svr.GetConsensusFailCount()) != 0 {
		riAdd = float64(svr.GetConsensusSuccessCount() / (svr.GetConsensusSuccessCount() + svr.GetConsensusFailCount()))
	} else { // 第一次共识  成功率为1  失败率为0
		riAdd = 1.00
	}

	tNow := util.Timestamp()                         //微秒
	ti := float64(tNow - svr.ConsensusFailTimeStamp) // 直接减
	GammaSet := svr.TestParams["Gamma"].(float64)

	RcColl := svr.GetRcColl(requestMsg.Committees)

	/*// 是否为生成节点i0
	firstServerID := requestMsg.Nodei.(*Server).ID
	isCreatedNode := false
	if svr.ID == firstServerID {
		isCreatedNode = true
	}else {
		isCreatedNode = false
	}*/

	// R1iAdd(R1i float64, riAdd float64, ti float64, GammaSet float64, RcColl []float64, isCreatedNode bool) (R1iNew float64)
	CreditNew := Credit.R1iAdd(R1i, riAdd, ti, GammaSet, RcColl, isCreatedNode)

	return CreditNew
}

//
func (svr *Server) GetCreditValue(msg *message.Message, isCreatedNode bool, OldCredit float64) Credit.Credit_Node {
	// 计算得到新信用值
	creditNew := svr.CreditAdd(*msg, isCreatedNode, OldCredit)
	// 节点中信用值更新
	svr.SetSafeCreditValue(creditNew)
	// 区块中信用记录
	credit := Credit.Credit{Value: creditNew}
	creditNode := Credit.Credit_Node{NodeID: svr.ID, Credit: credit}
	//svr.CreditSubtract(msg,true)  // 测试
	return creditNode
}

//将信誉值记录到新区块中
func (svr *Server) SetCredit(block *Block.Block, Credits []Credit.Credit_Node) {
	svr.Mu.Lock()
	block.Credits = Credits
	svr.Mu.Unlock()
}
