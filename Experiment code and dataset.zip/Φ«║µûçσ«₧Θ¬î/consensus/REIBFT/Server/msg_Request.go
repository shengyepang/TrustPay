package Server

import (
	"consensus/REIBFT/Credit"
	TypeMessage "consensus/REIBFT/Message"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
	cmap "github.com/orcaman/concurrent-map"
)

//处理接收到的Request消息
func (svr *Server) HandleRequest(msg message.Message) {
	height := svr.GetBlockChanHeight()
	data := msg.Payload.(*TypeMessage.Message_State)
	// 将共识状态设置为预准备阶段
	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_RePrepare_Nomal)
	// 记录首次消息时间
	svr.SaveCheckAbortMaxDeadLineTime(msg.RequestID)
	data.Message.Block.NodeID = svr.ID
	data.Message.Block.Header.Height = height
	// 验证生成区块的节点的信誉值
	if svr.GetSafeCreditValue() < Credit.Rmin {
		svr.SetConsensusFail(&svr.PrepareMsgs, &msg)
		return
	}
	t := util.Timestamp()
	msgs := &message.Message{ //消息的类型
		Type:      TypeMessage.PrePrepare.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: svr.BroadCastToCommittee(data.Message.Committees),
		RequestID: msg.RequestID,
		Payload:   msg.Payload,
	}
	//  监听 PrepareConsensusFail 事件
	svr.ListenTimeOut(&msg, &svr.PrepareMsgs, svr.PrePrepareConsensusFail) //监听
	svr.Send(*msgs)
}

// 监听 PrePrepare 阶段共识失败
func (svr *Server) PrePrepareConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 当前msg.RequestID是否已经完成PrePrepare阶段
	if d, y := svr.ConsensusStatus.Get(msg.RequestID); y {
		if d.(TypeMessage.MsgState) == TypeMessage.Msg_RePrepare_Success {
			return
		}
	}

	if svr.CheckAbortTimeOut(msg.RequestID) {
		// 出现错误，重复提交请求消息
		svr.HandleRequest(*msg)
	} else {
		svr.SetConsensusFail(Map, msg)
	}
}

// 如果出现错误则更新区块高度 重复提交
func (svr *Server) CheckAbortTimeOut(RequestID string) bool {
	MaxTimeOut := DeadLine / 1e3
	// 判断循环是否超过最大时间
	if d, y := svr.CheckAbortMaxDeadLineTime.Get(RequestID); !y {
		log.Error("没有找到RequestID")
		return false
	} else {
		time := util.Timestamp() - d.(int64)
		if time > int64(MaxTimeOut) {
			return false
		}
	}
	return true
}

// 获取客户端对应的委员会节点ID
func (svr *Server) BroadCastToCommittee(Committees []interface{}) []string {
	nodeids := make([]string, 0)
	for _, _node := range Committees {
		nodeids = append(nodeids, _node.(Server).GetID())
	}
	return nodeids
}

// 获取区块高度，此处是区块数量，即区块高度+1
func (svr *Server) GetBlockChanHeight() int64 {
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return int64(len(svr.BlockChan)) + 1
}

// 保存首次消息时间
func (svr *Server) SaveCheckAbortMaxDeadLineTime(RequestID string) {
	t := util.Timestamp()
	if !svr.CheckAbortMaxDeadLineTime.Has(RequestID) {
		// 记录消息起始日期
		svr.CheckAbortMaxDeadLineTime.Set(RequestID, t)
	}
}

// 发送失败消息
func (svr *Server) SetConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 处理委员会信用
	// 共识失败，直接调用commit阶段的共识失败函数，更新节点的信誉值
	svr.ConsensusFail(Map, msg)
	// 节点共识失败数量+1
	svr.AddConsensusFailCount()
	// 发送消息给客户端，反馈共识结果
	svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.PrePrepareAborted.String())
}
