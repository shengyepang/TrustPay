package Server

import "C"
import (
	"consensus/REIBFT"
	"consensus/REIBFT/Block"
	"consensus/common/pkg/message"
	"consensus/common/pkg/node"
	"consensus/common/pkg/request"
	"consensus/common/pkg/util"
	"context"
	"fmt"
	cmap "github.com/orcaman/concurrent-map"
	"strconv"
	"sync"
	"time"
)

type REIServertype int

var (
	// 投票等待时间
	VoteTimeOut = 100 * 1000 * time.Millisecond
	// Request超时时间
	DeadLine = 100 * 1000 * time.Millisecond
	// 上链时间
	WaitAddBlockTime = 100 * 1000 * time.Millisecond
)

// 服务节点,即参与共识的节点
type Server struct {
	*node.ServerBase
	ServerNO       int
	WorldState     cmap.ConcurrentMap     // map[string]Message_State 世界状态
	PrepareMsgs    cmap.ConcurrentMap     // map[string][]Message_State  Key 为RequestID
	CommitMsgs     cmap.ConcurrentMap     // map[string][]Message_State
	PreprepareMsgs cmap.ConcurrentMap     // map[string][]Message_State  key 为RequestID
	Servers        []interface{}          // 服务器节点列表
	Clients        []interface{}          // 客户端节点列表
	TestParams     map[string]interface{} // 测试平台传递的测试参数
	//Credit           Credit.Credit         // 信用值
	BlockChan                 []Block.Block             // 区块链
	CashBlock                 []Block.Block             // 缓存区块
	CommitteeNo               int                       // 委员会数量
	ConsensusSuccessCount     uint32                    // 共识成功数量
	ConsensusFailCount        uint32                    // 共识失败数量
	ConsensusFailTimeStamp    int64                     // 上一次失败时的时间
	SavePrepareHandleChannel  chan message.Message      // 接收Prepare消息
	SaveCommitHandleChannel   chan message.Message      // 接收Commit消息
	ReportCh                  chan<- *request.Event     // 实验报道通道
	TestCredit                *cmap.ConcurrentMap       // 记录所有服务节点的信用值（key为节点id，value为float64）
	TestCreditChan            chan<- *REIBFT.TestCredit // 统计实验测试中的信用数据
	ConsensusStatus           cmap.ConcurrentMap        // 共识状态 用来记录3阶段共识结果
	CheckAbortMaxDeadLineTime cmap.ConcurrentMap        // 判断循环超过最大的时间时 处于abort
	Servertype                REIServertype             // 区分服务器节点属于哪个微电网
}

// 注册服务节点数量
func (svr *Server) Init(ID string, ServerNO int, reportCh chan<- *request.Event) {
	svr.ServerBase = node.NewServerBase(ID, node.Server)
	svr.ServerNO = ServerNO
	svr.PrepareMsgs = cmap.New()
	svr.CommitMsgs = cmap.New()
	svr.PreprepareMsgs = cmap.New()
	//svr.Credit=Credit.Credit{Value: 0.5}
	svr.BlockChan = make([]Block.Block, 0)
	svr.CashBlock = make([]Block.Block, 0)
	svr.ReportCh = reportCh
	svr.ConsensusStatus = cmap.New()
	svr.CheckAbortMaxDeadLineTime = cmap.New()
}

// 获取当前服务器节点的信誉值
// 后期可能需要添加随机值的验证，补充（在客户端选取共识节点的时候有添加随机值）
func (svr *Server) GetSafeCreditValue() float64 {
	if svr.TestCredit == nil {
		return 0.5
	}
	data, _ := svr.TestCredit.Get(svr.ID)
	return data.(float64)
}

// 获取最新区块高度,第一个区块是0区块
func (svr *Server) GetLatestBlockChanHeight() int64 {
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return int64(len(svr.BlockChan))
}

// 获取最新区块
func (svr *Server) GetLatestBlock() *Block.Block {
	Height := svr.GetLatestBlockChanHeight() - 1
	if Height == -1 {
		return nil
	}
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return &svr.BlockChan[Height]
}

// 获取前一区块
func (svr *Server) GetBeforeBlock(height int64) *Block.Block {
	//高度为1的区块不存在前一区块
	if height == 0 {
		return nil
	}
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return &svr.BlockChan[height-1]
}

// 更新节点的信誉值
func (svr *Server) SetSafeCreditValue(v float64) {
	if svr.TestCredit == nil {
		return
	}
	svr.TestCredit.Set(svr.ID, v)
}

// 向客户端发送消息
func (svr *Server) SendClientMsg(RequestID, TargetID, Type string) {
	timestamp := util.Timestamp()
	// 发给客户端
	svr.Send(message.Message{
		Type:      Type,
		SendAt:    timestamp,
		SenderID:  svr.ID,
		TargetID:  TargetID,
		RequestID: RequestID,
		Payload:   nil,
	})
}

// 向测试平台中所有服务节点广播信誉值更新消息
func (svr *Server) SendCreditMsg(RequestID string, OldCredit float64) {
	timestamp := util.Timestamp()
	data := make(map[string]interface{})
	data["credit"] = fmt.Sprintf("%f", svr.GetSafeCreditValue())
	data["nodeid"] = svr.ID
	data["bft"] = svr.Node.Byzantine
	if svr.TestCreditChan != nil {
		if svr.TestParams["WaitGroup"] != nil {
			group := svr.TestParams["WaitGroup"].(*sync.WaitGroup)
			group.Add(1)
		}

		svr.TestCreditChan <- &REIBFT.TestCredit{
			ID:        RequestID + svr.ID,
			TimeStamp: timestamp,
			Bft:       svr.Node.Byzantine,
			NodeID:    svr.ID,
			RequestID: RequestID,
			NewCredit: svr.GetSafeCreditValue(),
			OldCredit: OldCredit,
		}
	}
	//fmt.Println(svr.ID+"  commit "+ fmt.Sprintf("%f",svr.GetSafeCreditValue()))
	//svr.ReportCh <- &request.Event{
	//	Status:    request.Credit,
	//	ID:        RequestID,
	//	Timestamp:timestamp,
	//	ClientID:  svr.ID,
	//	Data: data,
	//}
}

// 监听事件
func (svr *Server) ListenTimeOut(msg *message.Message, Map *cmap.ConcurrentMap, fail func(*cmap.ConcurrentMap, *message.Message)) {
	if Map.Has(msg.RequestID) {
		return
	}
	// 投票等待时间
	Ctx, _ := context.WithTimeout(context.Background(), VoteTimeOut)
	go func() {
		for {
			select {
			// 每隔一次投票等待时间，循环一次
			// 即到了投票等待时间，会发送消息到Ctx.Done()通道，便会执行对应的fail函数
			case <-Ctx.Done():
				fail(Map, msg)
				return
			}
		}
	}()
}

// 依据委员会数量计算拜占庭中的f,
func (svr *Server) GetBFTCount() int {
	return (svr.CommitteeNo - 1) / 3
}

// 获取服务器对应的节点
func (svr *Server) GetNode() *node.Node {
	return svr.Node
}

// 添加服务器节点的节点列表
func (svr *Server) SetNodes(servers []interface{}, clients []interface{}) {
	svr.Servers = servers
	svr.Clients = clients
	svr.ListenAddBlock()
}

// 设置测试参数
func (svr *Server) SetTestParams(param map[string]interface{}) {
	svr.TestParams = param
	voteTimeOut, _ := strconv.ParseFloat(param["VoteTimeOut"].(string), 10)
	VoteTimeOut = time.Duration(voteTimeOut*1000) * time.Millisecond
	deadLine, _ := strconv.ParseFloat(param["DeadLine"].(string), 10)
	DeadLine = time.Duration(deadLine*1000) * time.Millisecond
	waitAddBlockTime, _ := strconv.ParseFloat(param["WaitAddBlockTime"].(string), 10)
	WaitAddBlockTime = time.Duration(waitAddBlockTime*1000) * time.Millisecond
	svr.CommitteeNo = int(param["CommitteeNo"].(int64))
	if param["Credit"] != nil {
		svr.TestCredit = param["Credit"].(*cmap.ConcurrentMap)
	}

	if param["CreditChan"] != nil {
		svr.TestCreditChan = param["CreditChan"].(chan *REIBFT.TestCredit)
	}
}

func (svr *Server) Reitype(num int) {
	svr.Servertype = REIServertype(num)
}
