package Server

import (
	"consensus/REIBFT/Credit"
	TypeMessage "consensus/REIBFT/Message"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	cmap "github.com/orcaman/concurrent-map"
	"sync/atomic"
)

func (svr *Server) HandleCommit(msg message.Message) {
	// 基于超时时间监听通道，并执行超时函数
	svr.ListenTimeOut(&msg, &svr.CommitMsgs, svr.CommitConsensusFail)
	data := msg.Payload.(*TypeMessage.Message_State)
	// 将消息保存到本节点中
	svr.SaveHandleMessage(msg.RequestID, data, &svr.CommitMsgs)
	// 统计已经接收到的消息的数量
	count := svr.GetHandleMessageCount(msg.RequestID, &svr.CommitMsgs)
	// 基于拜占庭的共识结果判断
	if count == -1 { //共识失败
		log.Error("获取Commit失败，没有找到 " + msg.RequestID + " 消息")
		svr.CommitConsensusFail(nil, &msg)
		return
	}
	// 此处N应该是共识组节点的数量，之后需要修改，提现区域能源互联网中微电网的内部共识
	if count == 2*svr.GetBFTCount()+1 {
		svr.CommitConsensusSuccess(&msg)
	}
}

// 共识成功
func (svr *Server) CommitConsensusSuccess(msg *message.Message) {
	// 获取服务器节点的信誉值
	OldCredit := svr.GetSafeCreditValue()
	// Has验证Map中是否包含key对应的value
	if !svr.CommitMsgs.Has(msg.RequestID) {
		log.Info(svr.ID + " " + msg.RequestID + " 已经超时失效")
		return
	}
	// 累计成功数量+1
	svr.AddConsensusSuccessCount()
	data := msg.Payload.(*TypeMessage.Message_State)
	requestMsg := data.Message
	Credits := make([]Credit.Credit_Node, 0)

	// 如果是i0或委员会节点 则更新信用值
	firstServerID := requestMsg.Nodei.(*Server).ID
	if svr.ID == firstServerID { // 是i0节点
		creditNode := svr.GetCreditValue(msg, true, OldCredit)
		Credits = append(Credits, creditNode)
	}
	Committees := requestMsg.Committees
	for _, _node := range Committees {
		nodeID := _node.(Server).ID
		if svr.ID == nodeID { // 是委员会节点
			creditNode := svr.GetCreditValue(msg, false, OldCredit)
			Credits = append(Credits, creditNode)
		}
	}

	// 将服务器节点信用值记录到新区块中
	svr.SetCredit(data.Message.Block, Credits)
	// 将新区块添加到缓存区块链中
	svr.ReceiveCommitBlock(*data.Message.Block)
	// 向测试平台发送信誉值消息
	svr.SendCreditMsg(msg.RequestID, OldCredit)
	// 向测试平台发送消息
	svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.Commit.String())
}

//共识成功数量+1
func (svr *Server) AddConsensusSuccessCount() {
	//svr.ConsensusFailCount=atomic.AddUint32(&svr.ConsensusFailCount, 1)
	svr.RMu.Lock()
	defer svr.RMu.Unlock()
	atomic.AddUint32(&svr.ConsensusSuccessCount, 1)
}

// Commit共识失败
func (svr *Server) CommitConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 添加节点共识失败数量
	svr.AddConsensusFailCount()
	svr.ConsensusFail(Map, msg)
	svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.Aborted.String())
}

// 共识失败
func (svr *Server) ConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	//获取之前的信誉值
	OldCredit := svr.GetSafeCreditValue()
	// 信用更新
	data := msg.Payload.(*TypeMessage.Message_State)
	requestMsg := data.Message

	// 如果是i0或委员会节点 则更新信用值
	firstServerID := requestMsg.Nodei.(*Server).ID
	if svr.ID == firstServerID { // 是i0节点
		// 计算新的信誉值
		creditNew := svr.CreditSubtract(*msg, true, OldCredit)
		// 节点中信用值更新
		svr.SetSafeCreditValue(creditNew)
	}

	Committees := requestMsg.Committees
	for _, _node := range Committees {
		nodeID := _node.(Server).ID
		if svr.ID == nodeID { // 是委员会节点
			//计算新的信誉值
			creditNew := svr.CreditSubtract(*msg, false, OldCredit)
			// 节点中信用值更新
			svr.SetSafeCreditValue(creditNew)
		}
	}
	//将信誉值发送给测试平台，记录信誉数据
	svr.SendCreditMsg(msg.RequestID, OldCredit)
}

// 获取节点共识成功的数量
func (svr *Server) GetConsensusSuccessCount() uint32 {
	//svr.ConsensusFailCount=atomic.AddUint32(&svr.ConsensusFailCount, 1)
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return svr.ConsensusSuccessCount
}

// 获取节点共识失败的数量
func (svr *Server) GetConsensusFailCount() uint32 {
	//svr.ConsensusFailCount=atomic.AddUint32(&svr.ConsensusFailCount, 1)
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return svr.ConsensusFailCount
}

// 添加节点共识失败数量
func (svr *Server) AddConsensusFailCount() {
	//svr.ConsensusFailCount=atomic.AddUint32(&svr.ConsensusFailCount, 1)
	svr.RMu.Lock()
	defer svr.RMu.Unlock()
	atomic.AddUint32(&svr.ConsensusFailCount, 1)
}
