package Server

import (
	"consensus/REIBFT/Block"
	"consensus/REIBFT/Credit"
	TypeMessage "consensus/REIBFT/Message"
	"consensus/REIBFT/Model"
	"consensus/REIBFT/Tool"
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
)

func (svr *Server) HandlePrePrepare(msg message.Message) {

	data := msg.Payload.(*TypeMessage.Message_State)
	// 是否是BFT节点
	if svr.Byzantine {
		return
	}
	//验证区块高度
	if !svr.VerifyHeight(data.Message.Block) {
		log.Info(svr.ID + " 新区块高度验证失败")
		return
	}

	//验证委员会成员的信誉值
	if !svr.VerifyCommitteeCredit(data.Message) {
		log.Info(svr.ID + " 验证委员会成员的信誉值失败")
		return
	}

	//VDF验证
	if v, y := svr.TestParams["Vdf"]; y {
		if v.(string) == "1" {
			if !Tool.VDF_Verify(data.Message.VDFSeed, data.Message.VDF) {
				return
			}
		}
	}
	// 时间戳验证是否合法

	// 将收到的preprepare状态的包含区块的消息保存到本节点中
	svr.SetPrepreparemsg(&msg)
	t := util.Timestamp()
	newmsg := &message.Message{ //消息的类型
		Type:      TypeMessage.Prepare.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: svr.BroadCastToCommitteeandnodei(data.Message.Committees, data.SendID),
		RequestID: msg.RequestID,
		Payload:   data,
	}
	svr.Send(*newmsg) //网络延迟
}

// 获取本消息对应的委员会节点（共识节点）
func (svr *Server) BroadCastToCommitteeandnodei(Committees []interface{}, sendid string) []string {
	nodeids := make([]string, 0)
	for _, _node := range Committees {
		nodeids = append(nodeids, _node.(Server).GetID())
	}
	//添加生成区块节点的ID
	nodeids = append(nodeids, sendid)
	return nodeids
}

// 将收到的区块的preprepare状态消息保存到本server节点中
func (svr *Server) SetPrepreparemsg(msg *message.Message) {
	prepreparemsg := msg.Payload.(*TypeMessage.Message_State)
	//data,_ := Tool.Digest(prepreparemsg.Message.Block)
	svr.PreprepareMsgs.Set(msg.RequestID, prepreparemsg)
}

// 验证委员会节点的信誉值是否合理
func (svr *Server) VerifyCommitteeCredit(Rmessage *Model.RequestMessage) bool {
	for i := 0; i < len(Rmessage.Committees); i++ {
		node := Rmessage.Committees[i].(Server)
		if node.GetSafeCreditValue() < Credit.Rmin {
			return false
		}
	}
	return true
}

//判断区块高度是否合理
func (svr *Server) VerifyHeight(block *Block.Block) bool {
	latestblock := svr.GetLatestBlock()
	for latestblock != nil {
		//新区块的高度小于当前区块的高度并且其时间戳大于当前区块的时间戳
		if block.Header.Height < latestblock.Header.Height && block.Header.Timestamp > latestblock.Header.Timestamp {
			return false
		}
		//新区块的高度大于当前区块的高度并且其时间戳小于当前区块的时间戳
		if block.Header.Timestamp < latestblock.Header.Timestamp && block.Header.Height > latestblock.Header.Height {
			return true
		}
		//访问前一个区块
		latestblock = svr.GetBeforeBlock(latestblock.Header.Height - 1)
	}
	return true
}
