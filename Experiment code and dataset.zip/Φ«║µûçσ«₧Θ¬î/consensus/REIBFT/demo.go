package REIBFT

import (
	"consensus/common/pkg/geography"
	"consensus/internal/env"
	"consensus/internal/experiment"
	"consensus/internal/variate"
	"fmt"
	"github.com/jinzhu/gorm"
)

// 服务端节点数量逐渐增多实验
// 服务端节点数量从10增加到200，每次增加10个，每次增加的服务端节点都平均到所有微电网
func Exp1(db *gorm.DB, clientType, serverType string) {
	// 配置实验变量
	exp1And5Var := variate.NewIntVariate(env.ServerNO, 50, 200, 10)
	// 客户端节点固定为20个
	exp1AndEnv := env.New(20, 50, 2, 0, 0.1, geography.Local, 10)
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["CommitteeNo"] = int64(4) // 委员会数量
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("exp_1_and_5", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}

// 多组节点并发实验
func Exp2(db *gorm.DB, clientType, serverType string) {
	// 创建实验变量
	// 客户端节点数量从10增加到200，每次增加10个；微电网数量为1，即所有服务器节点均属于同一个微电网
	exp1And5Var := variate.NewIntVariate(env.ClientNO, 10, 200, 10)
	exp1AndEnv := env.New(10, 100, 2, 0, 0.1, geography.Local, 1) //服务端节点固定为100个
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["CommitteeNo"] = int64(4) //  委员会数量
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	fmt.Println(exp1And5Var, exp1AndEnv, TestParams)
	experiment.Run("exp_1_and_5", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}

// 微电网数目扩展实验（每次增加一个微电网）
func Exp3(db *gorm.DB, clientType, serverType string) {
	//创建实验变量
	//服务端节点从10开始每次增加10个，且这十个属于同一个微电网，即每次增加一个微电网
	exp1And5Var := variate.NewIntVariate(env.ServerNO, 100, 100, 10)
	exp1AndEnv := env.New(20, 100, 2, 0, 0.1, geography.Local, 10) //客户端节点固定20个
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["CommitteeNo"] = int64(4) //  委员会数量
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("exp_1_and_5", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}

// 客户端延迟对比实验
func Exp4(db *gorm.DB, clientType, serverType string) {
	//创建实验变量
	//客户端节点数从10增加到100，每次10个；服务器节点数固定为100，但是微电网数量从1-10变动（本实验需要进行10次测试，对应1-10微电网数量的设定）
	exp1And5Var := variate.NewIntVariate(env.ClientNO, 10, 100, 10)
	exp1AndEnv := env.New(10, 100, 2, 0, 0.1, geography.Local, 10) //服务端节点固定为100个
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["CommitteeNo"] = int64(4) //  委员会数量
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("exp_1_and_5", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}
