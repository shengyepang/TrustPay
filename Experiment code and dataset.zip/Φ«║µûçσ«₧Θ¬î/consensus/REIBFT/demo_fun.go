package REIBFT

import (
	"consensus/common/pkg/log"
	"fmt"
	"github.com/jinzhu/gorm"
	cmap "github.com/orcaman/concurrent-map"
	"strconv"
	"sync"
	"time"
)

func execExp11(TestParams map[string]interface{}, serverNO int, fun func()) {
	TestParams["Credit"] = getMapCredit(serverNO) //  最终信用记录值
	chans := make(chan *TestCredit, serverNO)
	TestParams["CreditChan"] = chans // 信用记录明细
	dbName := fmt.Sprintf("Credit_%v.db", time.Now().Format("2006_01_02-15_04_05"))
	credit_Db := initDB(dbName)
	group := new(sync.WaitGroup)
	TestParams["WaitGroup"] = group
	go func() {
		for {
			select {
			case data := <-chans:
				//将数据存储到数据库中
				Insert(credit_Db, &data)
				group.Done()
			}
		}
	}()
	fun()
	log.Info("正在统计信用数据")
	group.Wait()
	TestParams["Credit"].(*cmap.ConcurrentMap).IterCb(func(key string, item interface{}) {
		creditsimple := CreditSimple{key, item.(float64)}
		//将数据存储到数据库中
		Insert(credit_Db, &creditsimple)
	})
	log.Info("统计信用数据完成")
}

func getMapCredit(n int) *cmap.ConcurrentMap {
	maps := cmap.New()
	for i := 0; i < n; i++ {
		var values float64
		values = 0.5
		maps.Set("server_"+strconv.Itoa(i), values)
	}
	return &maps
}

type TestCredit struct {
	ID        string `gorm:"primary_key"`
	RequestID string
	NodeID    string
	TimeStamp int64   `gorm:"type:int"`
	OldCredit float64 `gorm:"type:decimal"`
	NewCredit float64 `gorm:"type:decimal"`
	Bft       bool    `gorm:"type:bool"`
}

type CreditSimple struct {
	Id     string  `gorm:"primary_key"`
	Credit float64 `gorm:"type:decimal"`
}

//创建数据库存储数据
func Insert(db *gorm.DB, st interface{}) {
	//将数据插入到数据库列表中
	db.Create(st)
}

func initDB(name string) *gorm.DB {
	if db, err := gorm.Open("sqlite3", name+"?cache=shared"); err != nil {
		return nil
	} else {
		db.AutoMigrate(&TestCredit{})
		db.AutoMigrate(&CreditSimple{})
		return db
	}
}
