## Install Dependency
```bash
export GOPROXY=https://goproxy.io,https://mirrors.aliyun.com/goproxy/,https://goproxy.cn,direct
export GO111MODULE=on
go mod download
```
## Develop
```bash
go run cmd/
```
## Test
```bash
go run main.go -t rc -f exp1
注释: -t 算法名称, -f 测试函数名称
```
## 文件解析
```cgo
cmd:       命令执行入口
common:    区块、节点等基础包
internal:  实验测试通用数据
raft:      raft共识算法具体代码
rc:        裁判节点共识算法
REIBFT:    微电网共识算法
```