package model

import (
	"consensus/raft/block"
)

type RequestMessage struct {
	VDFSeed    [32]byte
	VDF        [516]byte
	Committees []interface{}
	Nodei      interface{}
	Block      *block.Block
}
