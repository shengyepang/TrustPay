package raft

import (
	"consensus/common/pkg/geography"
	"consensus/internal/env"
	"consensus/internal/experiment"
	"consensus/internal/variate"
	"github.com/jinzhu/gorm"
)

/*
1、相关包均创建完毕
2、所有关于信誉、微电网分类的设定均需要修改
3、共识流程修改(不再基于3段式流程)
*/

// 客户端多组节点并发实验
func Exp1(db *gorm.DB, clientType, serverType string) {
	// 客户端节点数量从 initnumb 增加到 limitnumb，每次增加10个
	initnumb := int64(100)
	limitnumb := int64(200)
	serverNumb := int64(20)
	exp1And5Var := variate.NewIntVariate(env.ClientNO, initnumb, limitnumb, 100)
	// reinumb为微电网个数(raft算法用不到)
	exp1AndEnv := env.New(initnumb, serverNumb, 2, 0, 0.1, geography.Local, 1)
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("Exp1", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}

// 服务端节点增多实验
func Exp2(db *gorm.DB, clientType, serverType string) {
	// 客户端节点数量从 initnumb 增加到 limitnumb，每次增加10个
	initnumb := int64(10)
	limitnumb := int64(10)
	clientnumb := int64(1)
	exp1And5Var := variate.NewIntVariate(env.ServerNO, initnumb, limitnumb, 10)
	// reinumb为微电网个数(raft算法用不到)
	exp1AndEnv := env.New(clientnumb, initnumb, 2, 0, 0.1, geography.Local, 1)
	TestParams := make(map[string]interface{})
	TestParams["VoteTimeOut"] = "30"     // 网络等待时间
	TestParams["DeadLine"] = "200"       // 消息共识时间
	TestParams["WaitAddBlockTime"] = "1" // 出块时间单位秒
	TestParams["Vdf"] = "0"              // 是否开启延迟函数
	TestParams["Gamma"] = 0.05           // 信用体系参数值
	experiment.Run("Exp1", exp1And5Var, exp1AndEnv, db, clientType, serverType, TestParams, true)
}
