package server

import "C"
import (
	"consensus/common/pkg/message"
	"consensus/common/pkg/node"
	"consensus/common/pkg/request"
	"consensus/common/pkg/util"
	"consensus/raft/block"
	TypeMessage "consensus/raft/message"
	"context"
	cmap "github.com/orcaman/concurrent-map"
	"strconv"
	"time"
)

//type REIServertype int

var (
	// 投票等待时间
	VoteTimeOut = 100 * 1000 * time.Millisecond
	// Request超时时间
	DeadLine = 100 * 1000 * time.Millisecond
	// 上链时间
	WaitAddBlockTime = 100 * 1000 * time.Millisecond
)

// 服务节点,即参与共识的节点
type Server struct {
	*node.ServerBase
	ServerNO                  int
	WorldState                cmap.ConcurrentMap     // map[string]Message_State 世界状态
	PrepareMsgs               cmap.ConcurrentMap     // map[string][]Message_State  Key 为RequestID
	UnCommitMsgs              cmap.ConcurrentMap     // map[string][]Message_State  Key 为RequestID
	CommitMsgs                cmap.ConcurrentMap     // map[string][]Message_State
	Servers                   []interface{}          // 服务器节点列表
	Clients                   []interface{}          // 客户端节点列表
	TestParams                map[string]interface{} // 测试平台传递的测试参数
	BlockChan                 []block.Block          // 区块链
	CashBlock                 []block.Block          // 缓存区块
	ConsensusSuccessCount     uint32                 // 共识成功数量
	ConsensusFailCount        uint32                 // 共识失败数量
	SaveUncommitHandleChannel chan message.Message   // 接收 uncommit 消息
	SaveCommitHandleChannel   chan message.Message   // 接收 Commit 消息
	ReportCh                  chan<- *request.Event  // 实验报道通道
	ConsensusStatus           cmap.ConcurrentMap     // 共识状态 用来记录3阶段共识结果
	CheckAbortMaxDeadLineTime cmap.ConcurrentMap     // 判断循环超过最大的时间时 处于abort
}

// 注册服务节点数量
func (svr *Server) Init(ID string, ServerNO int, reportCh chan<- *request.Event) {
	svr.ServerBase = node.NewServerBase(ID, node.Server)
	svr.ServerNO = ServerNO
	svr.PrepareMsgs = cmap.New()
	svr.UnCommitMsgs = cmap.New()
	svr.CommitMsgs = cmap.New()
	svr.BlockChan = make([]block.Block, 0)
	svr.CashBlock = make([]block.Block, 0)
	svr.ReportCh = reportCh
	svr.ConsensusStatus = cmap.New()
	svr.CheckAbortMaxDeadLineTime = cmap.New()
}

// 获取最新区块高度,第一个区块是0区块
func (svr *Server) GetLatestBlockChanHeight() int64 {
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return int64(len(svr.BlockChan))
}

// 获取最新区块
func (svr *Server) GetLatestBlock() *block.Block {
	Height := svr.GetLatestBlockChanHeight() - 1
	if Height == -1 {
		return nil
	}
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return &svr.BlockChan[Height]
}

// 获取前一区块
func (svr *Server) GetBeforeBlock(height int64) *block.Block {
	//高度为1的区块不存在前一区块
	if height == 0 {
		return nil
	}
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return &svr.BlockChan[height-1]
}

// 向客户端发送消息
func (svr *Server) SendClientMsg(RequestID, TargetID, Type string) {
	timestamp := util.Timestamp()
	// 发给客户端
	svr.Send(message.Message{
		Type:      Type,
		SendAt:    timestamp,
		SenderID:  svr.ID,
		TargetID:  TargetID,
		RequestID: RequestID,
		Payload:   nil,
	})
}

// 监听事件
func (svr *Server) ListenTimeOut(msg *message.Message, Map *cmap.ConcurrentMap, fail func(*cmap.ConcurrentMap, *message.Message)) {
	if Map.Has(msg.RequestID) {
		return
	}
	// 投票等待时间
	Ctx, _ := context.WithTimeout(context.Background(), VoteTimeOut)
	go func() {
		for {
			select {
			// 每隔一次投票等待时间，循环一次
			// 即到了投票等待时间，会发送消息到Ctx.Done()通道，便会执行对应的fail函数
			case <-Ctx.Done():
				fail(Map, msg)
				return
			}
		}
	}()
}

// 获取follower节点的数量
func (svr *Server) GetFollowNum() int {
	return len(svr.Servers)
}

// 获取服务器对应的节点
func (svr *Server) GetNode() *node.Node {
	return svr.Node
}

// 添加服务器节点的节点列表
func (svr *Server) SetNodes(servers []interface{}, clients []interface{}) {
	svr.Servers = servers
	svr.Clients = clients
	svr.ListenAddBlock()
}

// 设置测试参数
func (svr *Server) SetTestParams(param map[string]interface{}) {
	svr.TestParams = param
	voteTimeOut, _ := strconv.ParseFloat(param["VoteTimeOut"].(string), 10)
	VoteTimeOut = time.Duration(voteTimeOut*1000) * time.Millisecond
	deadLine, _ := strconv.ParseFloat(param["DeadLine"].(string), 10)
	DeadLine = time.Duration(deadLine*1000) * time.Millisecond
	waitAddBlockTime, _ := strconv.ParseFloat(param["WaitAddBlockTime"].(string), 10)
	WaitAddBlockTime = time.Duration(waitAddBlockTime*1000) * time.Millisecond
}

// 保存收到的消息到本节点
func (svr *Server) SaveHandleMessage(requestid string, msg *TypeMessage.Message_State, Map *cmap.ConcurrentMap) {
	// 本条请求消息已经存在缓存列表（已经从其他节点出收到过）
	if data, y := Map.Get(requestid); y {
		data = append(data.([]*TypeMessage.Message_State), msg)
		Map.Set(requestid, data)
	} else { // 本条请求消息第一次收到
		arrays := make([]*TypeMessage.Message_State, 0)
		arrays = append(arrays, msg)
		Map.Set(requestid, arrays)
	}
}

// 获取所有的服务器节点的ID列表
func (svr *Server) BroadCastToAllNode() []string {
	nodes := make([]string, 0)
	for _, _node := range svr.Servers {
		nodes = append(nodes, _node.(node.ImpServer).GetID())
	}
	return nodes
}

// 获取收到的消息数量
func (svr *Server) GetHandleMessageCount(requestid string, Map *cmap.ConcurrentMap) int {
	if data, y := Map.Get(requestid); y {
		return len(data.([]*TypeMessage.Message_State))
	}
	return -1
}

// 获取leader主节点ID
func (svr *Server) GetLeaderNode() string {
	return "server_0"
}
