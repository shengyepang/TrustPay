package server

import (
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
	TypeMessage "consensus/raft/message"
)

// leader节点处理follow返回的确认消息
func (svr *Server) HandleUncommit(msg message.Message) {
	data := msg.Payload.(*TypeMessage.Message_State)
	// 将消息存到节点本地
	svr.SaveHandleMessage(msg.RequestID, data, &svr.UnCommitMsgs)
	// 统计已经接收到的消息数量
	count := svr.GetHandleMessageCount(msg.RequestID, &svr.UnCommitMsgs)
	// 判断是否收到一半以上follower节点发来的确认消息
	if count > svr.GetFollowNum()/2 {
		//if count == svr.GetFollowNum()/2+1 {
		//	fmt.Println("消息ID", msg.RequestID, "确认消息数量:", count, "共识节点总数量:", svr.GetFollowNum())
		//}
		height := svr.GetBlockChanHeight()
		data.Message.Block.Header.Height = height
		svr.UncommitConsensusSuccess(&msg)
	}
}

// 收到超过一半以上follower节点的回复，广播commit消息
func (svr *Server) UncommitConsensusSuccess(msg *message.Message) {
	// 当前 msg.RequestID 是否已经完成PrePrepare阶段
	if d, y := svr.ConsensusStatus.Get(msg.RequestID); y {
		if d.(TypeMessage.MsgState) == TypeMessage.Msg_Uncommitted_Success {
			log.Info("消息:" + msg.RequestID + "leader已经收到足够的follower节点消息,共识已成功！")
			return
		}
	}

	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_Uncommitted_Success)

	if !svr.UnCommitMsgs.Has(msg.RequestID) {
		return
	}
	data := msg.Payload.(*TypeMessage.Message_State)
	t := util.Timestamp()
	newmsg := &message.Message{ //消息的类型
		Type:      TypeMessage.Commit.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: svr.BroadCastToAllNode(), // 定义消息接受节点
		RequestID: msg.RequestID,
		Payload:   data,
	}
	svr.Send(*newmsg) //网络延迟
	// 向测试平台发送消息
	//svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.Commit.String())
}
