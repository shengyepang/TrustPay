package server

import (
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	TypeMessage "consensus/raft/message"
	cmap "github.com/orcaman/concurrent-map"
	"sync/atomic"
)

/*
所有节点收到commit消息之后，更新本地区块链存储
*/
func (svr *Server) HandleCommit(msg message.Message) {
	// 基于超时时间监听通道，并执行超时函数
	svr.ListenTimeOut(&msg, &svr.CommitMsgs, svr.CommitConsensusFail)
	data := msg.Payload.(*TypeMessage.Message_State)
	// 将消息保存到本节点中
	svr.SaveHandleMessage(msg.RequestID, data, &svr.CommitMsgs)

	svr.CommitConsensusSuccess(&msg)

}

// 共识成功,更新最新区块
func (svr *Server) CommitConsensusSuccess(msg *message.Message) {
	// Has验证Map中是否包含key对应的value
	if !svr.CommitMsgs.Has(msg.RequestID) {
		log.Info(svr.ID + " " + msg.RequestID + " 已经超时失效")
		return
	}
	// 累计成功数量+1
	svr.AddConsensusSuccessCount()
	data := msg.Payload.(*TypeMessage.Message_State)

	// 将新区块添加到缓存区块链中
	svr.ReceiveCommitBlock(*data.Message.Block)

	// 向测试平台发送消息
	svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.Commit.String())
}

//共识成功数量+1
func (svr *Server) AddConsensusSuccessCount() {
	//svr.ConsensusFailCount=atomic.AddUint32(&svr.ConsensusFailCount, 1)
	svr.RMu.Lock()
	defer svr.RMu.Unlock()
	atomic.AddUint32(&svr.ConsensusSuccessCount, 1)
}

// Commit共识失败
func (svr *Server) CommitConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 添加节点共识失败数量
	svr.AddConsensusFailCount()
	if svr.ID == svr.GetLeaderNode() {
		svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.Aborted.String())
	}
}

// 添加节点共识失败数量
func (svr *Server) AddConsensusFailCount() {
	svr.RMu.Lock()
	defer svr.RMu.Unlock()
	atomic.AddUint32(&svr.ConsensusFailCount, 1)
}
