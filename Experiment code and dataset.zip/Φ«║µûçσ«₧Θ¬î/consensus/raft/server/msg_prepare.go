package server

import (
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
	"consensus/raft/block"
	TypeMessage "consensus/raft/message"
	"consensus/raft/tool"
)

/*
1、follow节点接受leader节点发送的消息
2、将消息存储到本地，然后给leader节点回复确认消息
*/
func (svr *Server) HandlePrepare(msg message.Message) {
	data := msg.Payload.(*TypeMessage.Message_State)

	//验证区块高度
	if !svr.VerifyHeight(data.Message.Block) {
		log.Info(svr.ID + " 新区块高度验证失败")
		return
	}

	//VDF验证
	if v, y := svr.TestParams["Vdf"]; y {
		if v.(string) == "1" {
			if !tool.VDF_Verify(data.Message.VDFSeed, data.Message.VDF) {
				return
			}
		}
	}

	// 将消息存到节点本地
	svr.SaveHandleMessage(msg.RequestID, data, &svr.PrepareMsgs)

	svr.PrepareConsensusSuccess(&msg)
}

// 准备阶段完成后，对消息进行处理
func (svr *Server) PrepareConsensusSuccess(msg *message.Message) {
	// 当前 msg.RequestID 是否已经完成Prepare阶段
	if d, y := svr.ConsensusStatus.Get(msg.RequestID); y {
		if d.(TypeMessage.MsgState) == TypeMessage.Msg_Prepare_Success {
			log.Info("prepare已经完成")
			return
		}
	}

	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_Prepare_Success)
	if !svr.PrepareMsgs.Has(msg.RequestID) {
		return
	}
	data := msg.Payload.(*TypeMessage.Message_State)
	t := util.Timestamp()
	newmsg := &message.Message{
		//消息的类型
		Type:      TypeMessage.Uncommitted.String(),
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: []string{svr.GetLeaderNode()}, // 定义消息接受节点(leader节点)
		RequestID: msg.RequestID,
		Payload:   data,
	}
	svr.Send(*newmsg) //网络延迟
}

//判断区块高度是否合理
func (svr *Server) VerifyHeight(block *block.Block) bool {
	latestblock := svr.GetLatestBlock()
	for latestblock != nil {
		//新区块的高度小于当前区块的高度并且其时间戳大于当前区块的时间戳
		if block.Header.Height < latestblock.Header.Height && block.Header.Timestamp > latestblock.Header.Timestamp {
			return false
		}
		//新区块的高度大于当前区块的高度并且其时间戳小于当前区块的时间戳
		if block.Header.Timestamp < latestblock.Header.Timestamp && block.Header.Height > latestblock.Header.Height {
			return true
		}
		//访问前一个区块
		latestblock = svr.GetBeforeBlock(latestblock.Header.Height - 1)
	}
	return true
}
