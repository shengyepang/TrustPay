package server

import (
	"consensus/common/pkg/message"
	"consensus/raft/block"
	"consensus/raft/tool"
	"time"
)

// 接收确认的区块
func (svr *Server) ReceiveCommitBlock(block block.Block) {
	svr.AddCashBlock(block)
}

// 将新区块添加到缓存链
func (ser *Server) AddCashBlock(block block.Block) {
	ser.Mu.Lock()
	defer ser.Mu.Unlock()
	ser.CashBlock = append(ser.CashBlock, block)
}

// 监听块 上链一次
func (svr *Server) ListenAddBlock() {
	// 间隔地多次等待，每次等待 WaitAddBlockTime 时长
	ticker := time.Tick(WaitAddBlockTime)
	//svr.SavePrepareHandleChannel = make(chan message.Message, len(svr.Clients)*len(svr.Servers))
	svr.SaveUncommitHandleChannel = make(chan message.Message, len(svr.Clients)*len(svr.Servers))
	svr.SaveCommitHandleChannel = make(chan message.Message, len(svr.Clients)*len(svr.Servers))
	go func() {
		for {
			select {
			case <-ticker:
				svr.GetBlockForAddChan()
			//case msg := <-svr.SavePrepareHandleChannel:
			//	svr.HandlePrepare(msg)
			case msg := <-svr.SaveUncommitHandleChannel:
				svr.HandleUncommit(msg)
			case msg := <-svr.SaveCommitHandleChannel:
				svr.HandleCommit(msg)
			}
		}
	}()
}

// 将缓存区块中的区块添加到区块链中
func (ser *Server) GetBlockForAddChan() {
	ser.Mu.Lock()
	lockBlock := ser.CashBlock
	ser.Mu.Unlock()

	Blocks := make([]*block.BlockSortHash, 0)
	for _, v := range lockBlock {
		hash, _ := tool.Digest(v.Body)
		Blocks = append(Blocks, &block.BlockSortHash{Block: v, Hash: hash})
	}
	if len(Blocks) == 0 {
		return
	}
	block.SortPerson(Blocks, func(p, q *block.BlockSortHash) bool {
		return q.Hash < p.Hash
	})
	// 将缓存区块链添加到区块链中
	ser.AddBlockChan(Blocks)
}

// 将缓存区块链中的区块添加到区块链中
func (ser *Server) AddBlockChan(Blocks []*block.BlockSortHash) {
	prehash := ""
	if len(ser.BlockChan) > 0 {
		prehash, _ = tool.Digest(ser.BlockChan[len(ser.BlockChan)-1])
	}
	for i, block := range Blocks {
		if i == 0 {
			block.Block.Header.PreHash = prehash
		} else {
			if i < len(Blocks)-1 {
				hash, _ := tool.Digest(block.Block)
				Blocks[i+1].Block.Header.PreHash = hash
			}
		}
		ser.RMu.Lock()
		block.Block.Header.Height = int64(len(ser.BlockChan)) + 1
		ser.BlockChan = append(ser.BlockChan, block.Block)
		ser.RMu.Unlock()
	}
	// 清空缓存
	ser.CashBlock = make([]block.Block, 0)
}
