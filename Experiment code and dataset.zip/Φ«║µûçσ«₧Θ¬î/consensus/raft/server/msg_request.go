package server

import (
	"consensus/common/pkg/log"
	"consensus/common/pkg/message"
	"consensus/common/pkg/util"
	TypeMessage "consensus/raft/message"
	cmap "github.com/orcaman/concurrent-map"
)

// leader节点处理接收到的Request消息
func (svr *Server) HandleRequest(msg message.Message) {
	data := msg.Payload.(*TypeMessage.Message_State)
	// 将共识状态设置为准备阶段
	svr.ConsensusStatus.Set(msg.RequestID, TypeMessage.Msg_Prepare_Nomal)
	// 记录首次消息时间
	svr.SaveCheckAbortMaxDeadLineTime(msg.RequestID)
	data.Message.Block.NodeID = svr.ID

	t := util.Timestamp()
	msgs := &message.Message{ //消息的类型
		Type:      TypeMessage.Prepare.String(), //根据具体的算法单独定义，
		SendAt:    t,
		SenderID:  svr.ID, //发送者
		ClientID:  msg.ClientID,
		TargetIDS: svr.BroadCastToCommitte(data.Message.Committees),
		RequestID: msg.RequestID,
		Payload:   msg.Payload,
	}

	// 监听 UncommitConsensusFail 事件,在规定时间内leader节点未收到足够的follower节点的投票
	svr.ListenTimeOut(&msg, &svr.UnCommitMsgs, svr.UncommitConsensusFail)
	svr.Send(*msgs)
}

// raft的follower节点返回的确认消息(即leader广播request后,没有收到50%以上的回应)
func (svr *Server) UncommitConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 当前 msg.RequestID 是否已经完成 Uncommitted 阶段
	if d, y := svr.ConsensusStatus.Get(msg.RequestID); y {
		if d.(TypeMessage.MsgState) == TypeMessage.Msg_Uncommitted_Success {
			return
		}
	}

	if svr.CheckAbortTimeOut(msg.RequestID) {
		// 未超时，重新提交请求消息
		svr.HandleRequest(*msg)
	} else {
		svr.SetConsensusFail(Map, msg)
	}
}

// 检测follower节点确认是否超时
func (svr *Server) CheckAbortTimeOut(RequestID string) bool {
	// 最大超时时间
	MaxTimeOut := DeadLine / 1e3
	// 判断循环是否超过最大时间
	if d, y := svr.CheckAbortMaxDeadLineTime.Get(RequestID); !y {
		log.Error("没有找到RequestID")
		return false
	} else {
		time := util.Timestamp() - d.(int64)
		if time > int64(MaxTimeOut) {
			return false
		}
	}
	return true
}

// 获取客户端对应的共识节点ID
func (svr *Server) BroadCastToCommitte(Committees []interface{}) []string {
	nodeids := make([]string, 0)
	for _, _node := range Committees {
		nodeids = append(nodeids, _node.(Server).GetID())
	}
	return nodeids
}

// 获取区块高度，此处是区块数量，即区块高度+1
func (svr *Server) GetBlockChanHeight() int64 {
	svr.RMu.RLock()
	defer svr.RMu.RUnlock()
	return int64(len(svr.BlockChan)) + 1
}

// 保存请求的首次消息时间
func (svr *Server) SaveCheckAbortMaxDeadLineTime(RequestID string) {
	t := util.Timestamp()
	if !svr.CheckAbortMaxDeadLineTime.Has(RequestID) {
		// 记录消息起始日期
		svr.CheckAbortMaxDeadLineTime.Set(RequestID, t)
	}
}

// 发送失败消息
func (svr *Server) SetConsensusFail(Map *cmap.ConcurrentMap, msg *message.Message) {
	// 处理委员会信用
	// 共识失败，直接调用commit阶段的共识失败函数，更新节点的信誉值
	//svr.ConsensusFail(Map, msg)
	// 节点共识失败数量+1
	svr.AddConsensusFailCount()
	// 发送消息给客户端，反馈共识结果
	svr.SendClientMsg(msg.RequestID, msg.ClientID, TypeMessage.PrePrepareAborted.String())
}
