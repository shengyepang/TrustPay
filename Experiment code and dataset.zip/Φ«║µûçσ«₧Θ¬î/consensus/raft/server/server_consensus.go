package server

import (
	"consensus/common/pkg/message"
	TypeMessage "consensus/raft/message"
)

//接收并解析消息
func (svr *Server) HandleMessage(msg message.Message) {
	switch msg.Type {
	// leader节点处理客户端节点的request消息
	case TypeMessage.Request.String():
		svr.HandleRequest(msg)
	// follower节点处理leader节点的广播消息
	case TypeMessage.Prepare.String():
		svr.HandlePrepare(msg)
	// leader节点收集follower节点返回的确认消息
	case TypeMessage.Uncommitted.String():
		svr.SaveUncommitHandleChannel <- msg
	// 所有节点处理确认消息，并更新存储新区块
	case TypeMessage.Commit.String():
		svr.SaveCommitHandleChannel <- msg
	}

}
