package raft

import "testing"

func Test_demo_test(t *testing.T) {
	n := getMapCredit(1)
	t.Log(n)
}
